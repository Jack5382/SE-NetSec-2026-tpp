import sys
import os
import json
import subprocess
import shutil
import site


def get_bandit_plugin_dir():
    """获取Bandit的官方插件目录"""
    try:
        import bandit
        return os.path.join(os.path.dirname(bandit.__file__), "plugins")
    except ImportError:
        # 如果导入失败，尝试从site-packages找
        for sp in site.getsitepackages():
            bandit_plugin_dir = os.path.join(sp, "bandit", "plugins")
            if os.path.exists(bandit_plugin_dir):
                return bandit_plugin_dir
        raise Exception("找不到Bandit的安装目录，请先安装Bandit")


def install_plugin(plugin_src: str) -> str:
    """临时安装插件到Bandit官方目录"""
    plugin_dir = get_bandit_plugin_dir()
    plugin_name = os.path.basename(plugin_src)
    plugin_dst = os.path.join(plugin_dir, plugin_name)

    # 复制插件
    shutil.copy2(plugin_src, plugin_dst)
    return plugin_dst


def uninstall_plugin(plugin_dst: str):
    """卸载临时安装的插件"""
    if os.path.exists(plugin_dst):
        os.remove(plugin_dst)


def scan_with_bandit(target_path: str, plugin_path: str) -> dict:
    """
    【题目要求】100%使用Bandit官方机制进行扫描
    自动安装/卸载插件，兼容所有Bandit版本
    """
    plugin_dst = None
    try:
        # 1. 自动安装插件
        plugin_dst = install_plugin(plugin_path)

        # 2. 构建Bandit命令
        cmd = [
            sys.executable, "-m", "bandit",
            "-t", "B901,B902",  # 只运行我们的自定义规则
            "-f", "json",
            "-o", "-",
            target_path
        ]

        # 3. 执行扫描
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=60
        )

        # 4. 解析结果
        try:
            bandit_output = json.loads(result.stdout)
        except json.JSONDecodeError:
            return {
                "error": "Bandit输出解析失败",
                "stderr": result.stderr,
                "stdout": result.stdout
            }

        # 5. 整理成网页友好的格式
        issues = []
        for issue in bandit_output.get("results", []):
            issues.append({
                "test_id": issue["test_id"],
                "severity": issue["issue_severity"],
                "confidence": issue["issue_confidence"],
                "description": issue["issue_text"],
                "file": issue["filename"],
                "line": issue["line_number"],
                "code_snippet": issue["code"]
            })

        return {
            "success": True,
            "scan_summary": {
                "total_lines_scanned": bandit_output["metrics"]["_totals"]["loc"],
                "total_issues_found": len(issues),
                "scan_date": bandit_output["generated_at"]
            },
            "severity_counts": bandit_output["metrics"]["_totals"]["SEVERITY"],
            "confidence_counts": bandit_output["metrics"]["_totals"]["CONFIDENCE"],
            "issues": issues
        }

    finally:
        # 6. 自动卸载插件，不留痕迹
        if plugin_dst:
            uninstall_plugin(plugin_dst)


# --------------------------
# 主程序入口
# --------------------------
if __name__ == "__main__":
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PLUGIN_FILE = os.path.join(CURRENT_DIR, "plugin", "sensitive_detector.py")

    if len(sys.argv) < 2:
        print("用法: python run_scan.py <要扫描的Python文件路径>")
        print("示例: python run_scan.py test_samples/vulnerable.py")
        sys.exit(1)

    target_path = sys.argv[1]

    if not os.path.exists(target_path):
        print(f"错误: 路径 '{target_path}' 不存在")
        sys.exit(1)

    print(f"正在使用Bandit扫描: {target_path} ...")
    result = scan_with_bandit(target_path, PLUGIN_FILE)

    print("\n" + "=" * 50)
    print("安全扫描结果")
    print("=" * 50)
    print(json.dumps(result, indent=2, ensure_ascii=False))

    output_file = "security_report.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    print(f"\n报告已保存至: {os.path.abspath(output_file)}")