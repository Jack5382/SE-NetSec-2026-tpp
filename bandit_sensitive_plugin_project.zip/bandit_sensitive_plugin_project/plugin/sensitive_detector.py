import bandit
from bandit.core import test_properties as test
import ast
import re

# --------------------------
# 配置区：可根据需求修改
# --------------------------
# 敏感关键词列表（不区分大小写）
SENSITIVE_PATTERNS = {
    'password', 'pwd', 'passwd', 'secret', 'token', 'api_key', 'apikey',
    'private_key', 'privatekey', 'access_key', 'accesskey', 'db_password',
    'database_password', 'aws_secret', 'aws_key', 'jwt_secret', 'auth_token'
}

# 最小敏感字符串长度（小于此长度不报警，减少误报）
MIN_SECRET_LENGTH = 5


# --------------------------
# 辅助函数
# --------------------------
def _is_sensitive_name(name: str) -> bool:
    """检查字符串是否包含敏感关键词"""
    if not name:
        return False
    name_lower = name.lower()
    return any(pattern in name_lower for pattern in SENSITIVE_PATTERNS)


def _looks_like_a_secret(value: str) -> bool:
    """简单的启发式规则：判断字符串是否像密钥"""
    if len(value) < MIN_SECRET_LENGTH:
        return False

    # 规则1: 包含大小写字母和数字的混合（常见于API Key）
    has_upper = any(c.isupper() for c in value)
    has_lower = any(c.islower() for c in value)
    has_digit = any(c.isdigit() for c in value)

    # 规则2: 包含特殊字符（如 _, -, =）
    has_special = bool(re.search(r'[_\-=]', value))

    # 规则3: 高熵值（随机字符串）- 简化版实现
    # 真正的熵值计算需要统计字符频率，这里用简单规则代替
    return (has_upper and has_lower) or has_digit or has_special


# --------------------------
# 检测规则 1: 检测赋值语句中的硬编码
# --------------------------
@test.checks('Assign', 'AnnAssign')
@test.test_id('B901')
def detect_hardcoded_secrets_in_assignment(context):
    """
    [B901] 检测赋值语句中的硬编码敏感信息
    例如: api_key = "sk_live_abc123"
    """
    node = context.node

    # 获取赋值目标（左侧）
    targets = node.targets if hasattr(node, 'targets') else [node.target]

    for target in targets:
        var_name = None

        # 处理简单变量名: secret = "..."
        if isinstance(target, ast.Name):
            var_name = target.id

        # 处理对象属性: config.secret = "..."
        elif isinstance(target, ast.Attribute):
            var_name = target.attr

        # 处理类型注解的变量: secret: str = "..."
        elif hasattr(target, 'id'):
            var_name = target.id

        # 执行检测
        if _is_sensitive_name(var_name):
            # 检查右侧值是否为字符串常量
            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                secret_val = node.value.value
                if _looks_like_a_secret(secret_val):
                    return bandit.Issue(
                        severity=bandit.HIGH,
                        confidence=bandit.MEDIUM,
                        text=f"[B901] 发现硬编码敏感信息: 变量 '{var_name}' = '{secret_val[:15]}...'"
                    )


# --------------------------
# 检测规则 2: 检测字典中的硬编码
# --------------------------
@test.checks('Dict')
@test.test_id('B902')
def detect_hardcoded_secrets_in_dict(context):
    """
    [B902] 检测字典定义中的硬编码敏感信息
    例如: config = {"api_key": "sk_live_abc123"}
    """
    node = context.node

    # 遍历字典的键值对
    for key_node, value_node in zip(node.keys, node.values):
        # 只处理字符串类型的键
        if isinstance(key_node, ast.Constant) and isinstance(key_node.value, str):
            dict_key = key_node.value

            if _is_sensitive_name(dict_key):
                # 检查值是否为字符串常量
                if isinstance(value_node, ast.Constant) and isinstance(value_node.value, str):
                    secret_val = value_node.value
                    if _looks_like_a_secret(secret_val):
                        return bandit.Issue(
                            severity=bandit.HIGH,
                            confidence=bandit.MEDIUM,
                            text=f"[B902] 发现字典中的硬编码敏感信息: 键 '{dict_key}' = '{secret_val[:15]}...'"
                        )