import sys
import os
import json
import subprocess
import shutil

if __name__ == "__main__":
    # 1. 路径配置
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PLUGIN_SRC = os.path.join(CURRENT_DIR, "plugin", "sensitive_detector.py")
    TARGET_FILE = sys.argv[1]

    # 2. 找到Bandit的插件目录
    import bandit

    BANDIT_PLUGINS = os.path.join(os.path.dirname(bandit.__file__), "plugins")
    PLUGIN_DST = os.path.join(BANDIT_PLUGINS, "sensitive_detector.py")

    try:
        # 3. 复制插件到官方目录（唯一能让老版本Bandit加载的方法）
        shutil.copy2(PLUGIN_SRC, PLUGIN_DST)

        # 4. 直接运行官方bandit命令
        result = subprocess.run(
            [sys.executable, "-m", "bandit", "-f", "json", TARGET_FILE],
            capture_output=True,
            text=True,
            encoding="utf-8"
        )

        # 5. 输出结果
        print(json.dumps(json.loads(result.stdout), indent=2, ensure_ascii=False))

    finally:
        # 6. 用完立刻删除，不留任何痕迹
        if os.path.exists(PLUGIN_DST):
            os.remove(PLUGIN_DST)