"""
Bandit 敏感信息检测插件
========================

基于 AST 的 Python 代码硬编码敏感信息检测工具，
是 Bandit 安全扫描器的企业级增强插件。

主要功能:
- 检测硬编码密码、API密钥、JWT令牌、数据库连接串、私钥等
- 智能误报过滤（注释、#nosec、测试代码、常量定义）
- YAML 格式自定义规则配置
- 与 Bandit 原生报告和命令行接口完全兼容
- 提供 GitHub Actions 和 pre-commit 集成模板

示例:
    命令行使用::
        $ bandit -r . -p bandit_sensitive_info

    pre-commit 集成::
        - repo: local
          hooks:
            - id: bandit-sensitive
              name: 敏感信息检测
              entry: bandit -p bandit_sensitive_info

版本: 1.0.0
兼容: Python 3.10+, Bandit 1.7.0+
"""

# 包版本号
__version__ = "1.0.0"

# 包的作者信息
__author__ = "TPP"
__license__ = "MIT"

# 导出的公共符号（方便外部直接 import）
from .plugin import register_plugins
from .core.models import DetectionRule, Finding, ScanResult
from .rules.rule_loader import RuleLoader

# 定义 from bandit_sensitive_info import * 时的导出列表
__all__ = [
    "register_plugins",    # 插件注册函数
    "DetectionRule",       # 规则定义类
    "Finding",             # 发现结果类
    "ScanResult",          # 扫描结果类
    "RuleLoader",          # 规则加载器
    "__version__",         # 版本号
]