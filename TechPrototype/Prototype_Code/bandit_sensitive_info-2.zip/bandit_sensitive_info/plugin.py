"""
Bandit 敏感信息检测插件（兼容 Bandit 1.9.4）
"""
import ast
import os
import re
import logging
from pathlib import Path

import bandit
from bandit.core import issue
from bandit.core import test_properties as test

from .rules.rule_loader import RuleLoader

logger = logging.getLogger(__name__)

# ============================================================
# 规则加载（一次性）
# ============================================================
_loader = RuleLoader()
_RULES = []


def _load_rules():
    global _RULES
    if _RULES:
        return _RULES
    try:
        rule_sets = _loader.load()
        for rs in rule_sets:
            for rule in rs.rules:
                try:
                    rule.compile_patterns()
                    _RULES.append(rule)
                except Exception:
                    pass
    except Exception as e:
        logger.error(f"规则加载失败: {e}")
    return _RULES


def _check_string(value, context):
    """检查字符串是否匹配任何规则"""
    rules = _load_rules()
    for rule in rules:
        if not rule.compiled_pattern:
            continue
        match = rule.compiled_pattern.search(value)
        if not match:
            continue
        if rule.is_excluded(value):
            continue
        return bandit.Issue(
            severity=bandit.HIGH if rule.severity.level == "HIGH"
            else bandit.MEDIUM if rule.severity.level == "MEDIUM"
            else bandit.LOW,
            confidence=bandit.HIGH if rule.severity.confidence == "HIGH"
            else bandit.MEDIUM if rule.severity.confidence == "MEDIUM"
            else bandit.LOW,
            cwe=issue.Cwe.HARD_CODED_PASSWORD,
            text=f"[{rule.rule_id}] {rule.description}: {value[:40]}",
            lineno=context.node.lineno,
        )
    return None


# ============================================================
# B901: 字符串中的敏感信息检测
# ============================================================
@test.checks("Str")
@test.test_id("B901")
def sensitive_info_string(context):
    """检测字符串字面量中的硬编码敏感信息"""
    node = context.node
    value = node.value if hasattr(node, 'value') else node.s

    if not isinstance(value, str) or len(value) < 6:
        return None

    # 直接用值匹配
    result = _check_string(value, context)
    if result:
        return result

    # 用整行代码匹配 password 类规则
    # Bandit 1.9.4: 通过 context.node.lineno 和源代码获取行内容
    try:
        # 获取源代码
        source = context._context._source if hasattr(context._context, '_source') else ''
        if source:
            lines = source.split('\n')
            lineno = node.lineno
            if lineno <= len(lines):
                code_line = lines[lineno - 1]
                if code_line != value:  # 避免重复匹配
                    result = _check_string(code_line, context)
                    if result:
                        return result
    except Exception:
        pass

    # 检查赋值上下文中的变量名
    if hasattr(node, '_bandit_parent') and isinstance(node._bandit_parent, ast.Assign):
        for targ in node._bandit_parent.targets:
            var_name = ""
            if isinstance(targ, ast.Name):
                var_name = targ.id
            elif isinstance(targ, ast.Attribute):
                var_name = targ.attr

            if var_name:
                # 构造 "变量名 = 值" 的格式
                fake_line = f'{var_name} = "{value}"'
                result = _check_string(fake_line, context)
                if result:
                    return result

    return None


# ============================================================
# B902: 函数调用参数中的敏感信息检测
# ============================================================
@test.checks("Call")
@test.test_id("B902")
def sensitive_info_funcarg(context):
    """检测函数调用参数中的硬编码敏感信息"""
    for kw in context.node.keywords:
        if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
            value = kw.value.value
            if len(value) < 6:
                continue
            result = _check_string(value, context)
            if result:
                return result
    return None


# ============================================================
# 插件注册（Bandit 1.9.4 要求）
# ============================================================
def register_plugins():
    """Bandit 插件注册入口"""
    print(f"[SensitiveInfo] 插件已注册，加载了 {len(_load_rules())} 条规则")
    return [
        ("B901", sensitive_info_string),
        ("B902", sensitive_info_funcarg),
    ]