"""
误报过滤器模块
=============

提供多层过滤机制，将误报率控制在5%以内。

过滤层级（按执行顺序，从快到慢）:
1. comment_filter: 注释与 #nosec 标记过滤
2. constant_filter: 常量定义与默认值过滤
3. test_code_filter: 测试代码过滤
"""

from .base import BaseFilter, FilterChain
from .comment_filter import CommentNosecFilter
from .constant_filter import ConstantFilter
from .test_code_filter import TestCodeFilter


def create_default_filter_chain():
    """
    创建默认的过滤器链

    按最优顺序排列: 从最快到最慢，优先执行低成本过滤。

    返回:
        配置好的 FilterChain 实例
    """
    chain = FilterChain()
    chain.add_filter(CommentNosecFilter())    # O(1) 字符串查找
    chain.add_filter(TestCodeFilter())        # O(1) 文件属性判断
    chain.add_filter(ConstantFilter())        # O(n) 上下文分析
    return chain


__all__ = [
    "BaseFilter",
    "FilterChain",
    "CommentNosecFilter",
    "ConstantFilter",
    "TestCodeFilter",
    "create_default_filter_chain",
]