"""
测试代码过滤器
==============

过滤测试文件和测试函数中的代码。

过滤规则:
1. 文件路径在 tests/ 或 test/ 目录中
2. 文件名以 test_ 开头或 _test 结尾
3. 文件名为 conftest.py
4. 函数名以 test_ 开头
"""

import logging
from pathlib import Path
from .base import BaseFilter
from ..core.models import Finding
from ..core.context import FileContext

logger = logging.getLogger(__name__)


class TestCodeFilter(BaseFilter):
    """
    测试代码过滤器

    识别并过滤测试代码中的硬编码值。
    测试代码中通常包含示例数据，不属于安全风险。
    """

    # 测试文件模式
    TEST_FILE_PATTERNS = [
        'test_*.py',
        '*_test.py',
        'conftest.py',
        'factories.py',
        'fixtures.py',
    ]

    # 测试目录名
    TEST_DIR_NAMES = ['tests', 'test', 'testing', '__pycache__']

    @property
    def name(self) -> str:
        return "TestCodeFilter"

    def filter(self, finding: Finding, file_ctx: FileContext) -> bool:
        """
        检查是否在测试代码中

        参数:
            finding: 待检查的发现
            file_ctx: 文件上下文

        返回:
            True 如果应被过滤
        """
        # 1. 快速检查: 使用文件上下文的预判断
        if file_ctx.is_test_file:
            logger.debug(
                f"#{finding.rule.rule_id} 在测试文件中 "
                f"({file_ctx.relative_path})，过滤"
            )
            return True

        # 2. 详细检查文件路径
        file_path = finding.location.file_path
        if self._is_test_file_path(file_path):
            logger.debug(f"#{finding.rule.rule_id} 文件路径识别为测试文件，过滤")
            return True

        # 3. 检查是否在测试函数中（通过行上下文）
        if self._is_in_test_function(finding, file_ctx):
            logger.debug(f"#{finding.rule.rule_id} 在测试函数中，过滤")
            return True

        return False

    def _is_test_file_path(self, file_path: str) -> bool:
        """
        判断文件路径是否为测试文件

        参数:
            file_path: 文件路径

        返回:
            True 如果是测试文件
        """
        path = Path(file_path)
        filename = path.name
        path_str = file_path.lower().replace('\\', '/')

        # 检查文件名模式
        if any(path.match(pattern) for pattern in self.TEST_FILE_PATTERNS):
            return True

        # 检查是否在测试目录中
        for test_dir in self.TEST_DIR_NAMES:
            if f'/{test_dir}/' in path_str or path_str.startswith(f'{test_dir}/'):
                return True

        return False

    def _is_in_test_function(self, finding: Finding, file_ctx: FileContext) -> bool:
        """
        检查当前行是否在测试函数内部

        通过向上查找最近的函数定义来判断。

        参数:
            finding: 发现对象
            file_ctx: 文件上下文

        返回:
            True 如果在测试函数中
        """
        current_line = finding.location.line_number

        # 向上查找最多 20 行，寻找函数定义
        start = max(1, current_line - 20)

        for i in range(current_line, start - 1, -1):
            line = file_ctx.get_line(i).strip()

            # 检查是否是测试函数定义
            if line.startswith('def test_'):
                return True

            # 检查是否是 unittest 测试方法
            if 'def test' in line and 'self' in line:
                return True

            # 遇到类定义或非测试函数定义，停止搜索
            if line.startswith('def ') and not line.startswith('def test_'):
                return False

            if line.startswith('class '):
                return False

        return False