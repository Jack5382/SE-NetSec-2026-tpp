
"""
过滤器基类与过滤器链
===================

定义过滤器的统一接口和过滤器链的执行逻辑。

过滤器链采用责任链模式，每个过滤器依次处理，
一旦某个过滤器判定应过滤，后续过滤器不再执行。
"""

import logging
from abc import ABC, abstractmethod
from typing import List, Optional

from ..core.models import Finding
from ..core.context import FileContext

logger = logging.getLogger(__name__)


class BaseFilter(ABC):
    """
    过滤器抽象基类

    所有过滤器必须继承此类并实现 filter 方法。

    设计原则:
    - 单一职责: 每个过滤器只负责一种误报类型
    - 无状态: 过滤器实例可在多线程中安全复用
    - 高效: filter 方法应尽可能快
    """

    @property
    def name(self) -> str:
        """过滤器名称"""
        return self.__class__.__name__

    @property
    def description(self) -> str:
        """过滤器描述"""
        return self.__doc__.split('\n')[0] if self.__doc__ else "无描述"

    @abstractmethod
    def filter(self, finding: Finding, file_ctx: FileContext) -> bool:
        """
        判断是否应该过滤此发现

        参数:
            finding: 待判断的发现
            file_ctx: 文件上下文

        返回:
            True 表示应被过滤（是误报）
            False 表示应保留（是真正的敏感信息）
        """
        pass

    def __repr__(self):
        return f"{self.name}()"


class FilterChain:
    """
    过滤器链（责任链模式）

    按顺序执行一系列过滤器，一旦某个过滤器返回 True（应过滤），
    立即停止后续过滤器的执行并返回 True。

    支持:
    - 动态添加/移除过滤器
    - 过滤器执行统计
    - 按优先级排序
    """

    def __init__(self):
        """初始化空的过滤器链"""
        self._filters: List[BaseFilter] = []

        # 过滤统计
        self._stats: dict = {
            "total_checked": 0,  # 总检查数
            "total_filtered": 0,  # 总过滤数
            "per_filter": {},  # 每个过滤器的过滤数
        }

    def add_filter(self, filter_obj: BaseFilter):
        """
        添加过滤器到链尾

        参数:
            filter_obj: 过滤器实例

        返回:
            self，支持链式调用
        """
        if not isinstance(filter_obj, BaseFilter):
            raise TypeError(f"过滤器必须继承 BaseFilter，当前: {type(filter_obj)}")

        self._filters.append(filter_obj)
        if filter_obj.name not in self._stats["per_filter"]:
            self._stats["per_filter"][filter_obj.name] = 0

        logger.debug(f"添加过滤器: {filter_obj.name}")
        return self

    def remove_filter(self, filter_name: str) -> bool:
        """
        按名称移除过滤器

        参数:
            filter_name: 过滤器名称

        返回:
            是否找到并移除
        """
        for i, f in enumerate(self._filters):
            if f.name == filter_name:
                self._filters.pop(i)
                logger.debug(f"移除过滤器: {filter_name}")
                return True
        return False

    def apply(self, finding: Finding, file_ctx: FileContext) -> bool:
        """
        应用过滤器链

        按顺序执行所有过滤器。

        参数:
            finding: 待检查的发现
            file_ctx: 文件上下文

        返回:
            True 表示应被过滤（是误报）
            False 表示应保留
        """
        self._stats["total_checked"] += 1

        for filter_obj in self._filters:
            try:
                should_filter = filter_obj.filter(finding, file_ctx)

                if should_filter:
                    self._stats["total_filtered"] += 1
                    self._stats["per_filter"][filter_obj.name] = \
                        self._stats["per_filter"].get(filter_obj.name, 0) + 1

                    logger.debug(
                        f"过滤器 '{filter_obj.name}' 过滤了: "
                        f"{finding.rule.rule_id} @ "
                        f"{finding.location.file_path}:{finding.location.line_number}"
                    )
                    return True

            except Exception as e:
                logger.error(f"过滤器 '{filter_obj.name}' 执行出错: {e}")
                # 过滤器出错时不阻止发现（安全起见，保留发现）
                continue

        return False

    def get_stats(self) -> dict:
        """
        获取过滤统计信息

        返回:
            包含过滤统计的字典
        """
        rate = 0.0
        if self._stats["total_checked"] > 0:
            rate = self._stats["total_filtered"] / self._stats["total_checked"]

        return {
            "total_checked": self._stats["total_checked"],
            "total_filtered": self._stats["total_filtered"],
            "filter_rate": f"{rate:.2%}",
            "per_filter": dict(self._stats["per_filter"]),
        }

    def clear_stats(self):
        """清除统计信息"""
        self._stats = {
            "total_checked": 0,
            "total_filtered": 0,
            "per_filter": {f.name: 0 for f in self._filters},
        }

    def __len__(self):
        return len(self._filters)

    def __iter__(self):
        return iter(self._filters)

    def __repr__(self):
        filter_names = [f.name for f in self._filters]
        return f"FilterChain({' → '.join(filter_names)})"