"""
注释与 #nosec 标记过滤器
========================

基于注释和 #nosec 安全标记的误报过滤。

过滤规则:
1. # nosec: 显式安全标记，表示该行已人工审查为安全
2. 纯注释行: 注释中的字符串不应被检测
3. 文档字符串: __doc__ 中的示例代码

这是最快、最优先执行的过滤器。
"""

import logging
from .base import BaseFilter
from ..core.models import Finding
from ..core.context import FileContext

logger = logging.getLogger(__name__)


class CommentNosecFilter(BaseFilter):
    """
    注释与 nosec 标记过滤器

    检查:
    - 是否被 #nosec 标记
    - 是否在注释中
    - 是否在文档字符串中
    """

    @property
    def name(self) -> str:
        return "CommentNosecFilter"

    def filter(self, finding: Finding, file_ctx: FileContext) -> bool:
        """
        检查是否应基于注释/nosec过滤

        参数:
            finding: 待检查的发现
            file_ctx: 文件上下文

        返回:
            True 如果应被过滤
        """
        line_content = finding.location.line_content

        if not line_content:
            line_content = file_ctx.get_line(finding.location.line_number)

        if not line_content:
            return False

        # ---- 检查 #nosec 标记 ----
        if self._has_nosec(line_content, file_ctx, finding.location.line_number):
            logger.debug(f"#{finding.rule.rule_id} 被 #nosec 过滤")
            finding.is_nosec_flagged = True
            return True

        # ---- 检查是否在注释中 ----
        if self._is_in_comment(line_content, finding.location.column_offset):
            logger.debug(f"#{finding.rule.rule_id} 在注释中，过滤")
            return True

        # ---- 检查是否在文档字符串中 ----
        if self._is_in_docstring(file_ctx, finding.location.line_number):
            logger.debug(f"#{finding.rule.rule_id} 在文档字符串中，过滤")
            return True

        return False

    def _has_nosec(self, line_content: str, file_ctx: FileContext,
                   line_number: int) -> bool:
        """
        检查是否有 #nosec 标记

        支持格式:
        - 行内: `password = "xxx"  # nosec`
        - 前一行: `# nosec` (单独一行时忽略下一行)

        参数:
            line_content: 当前行内容
            file_ctx: 文件上下文
            line_number: 行号

        返回:
            True 如果有 nosec 标记
        """
        # 1. 检查当前行
        stripped = line_content.strip()
        comment_pos = stripped.find('#')
        if comment_pos >= 0:
            comment = stripped[comment_pos:].lower()
            if 'nosec' in comment:
                return True

        # 2. 检查前一行（nosec 通常写在前一行的注释中）
        if line_number > 1:
            prev_line = file_ctx.get_line(line_number - 1).strip()
            if prev_line.startswith('#') and 'nosec' in prev_line.lower():
                return True

        # 3. 检查前一行行内注释的特殊情况
        if line_number > 1:
            prev = file_ctx.get_line(line_number - 1)
            if '#' in prev and 'nosec' in prev.split('#')[-1].lower():
                return True

        return False

    def _is_in_comment(self, line_content: str, column_offset: int) -> bool:
        """
        检查指定列位置是否在注释中

        参数:
            line_content: 代码行内容
            column_offset: 列偏移

        返回:
            True 如果在注释中
        """
        stripped = line_content.strip()

        # 整行都是注释
        if stripped.startswith('#'):
            return True

        # 查找 # 的位置
        comment_start = line_content.find('#')
        if comment_start >= 0 and column_offset >= comment_start:
            return True

        return False

    def _is_in_docstring(self, file_ctx: FileContext, line_number: int) -> bool:
        """
        检查指定行是否在文档字符串中

        简单启发式:
        - 检查附近是否有 单引号 或 双引号
        - 文档字符串通常出现在模块 / 类 / 函数开头

        参数:
        file_ctx: 文件上下文
        line_number: 行号

        返回:
        True
        如果可能在文档字符串中
        """

        # 检查前后5行是否有三引号
        start = max(1, line_number - 5)
        end = min(file_ctx.total_lines, line_number + 5)

        triple_quote_count = 0
        for i in range(start, end + 1):
            line = file_ctx.get_line(i)
            
            if '"""' in line or "'''" in line:
                triple_quote_count += 1

        # 如果附近有三引号（奇数可能表示在文档字符串内）
        return triple_quote_count >= 1 and triple_quote_count % 2 == 1