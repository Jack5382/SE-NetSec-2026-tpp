"""
常量定义与默认值过滤器
======================

过滤被识别为常量定义或默认值的误报。

过滤规则:
1. 变量名大写（CONSTANT_CASE）→ 可能是配置常量
2. 包含 default/example/test/dummy/placeholder 关键词
3. 变量名包含 CONFIG/SETTINGS/DEFAULT/TEMPLATE
"""

import re
import logging
from .base import BaseFilter
from ..core.models import Finding
from ..core.context import FileContext

logger = logging.getLogger(__name__)


class ConstantFilter(BaseFilter):
    """
    常量与默认值过滤器

    通过分析变量名和值的语义，识别配置常量、示例值等非安全敏感信息。
    """

    # 常量/默认值指示关键词（小写）
    CONSTANT_KEYWORDS = {
        'example', 'demo', 'test', 'dummy', 'placeholder',
        'changeme', 'default', 'template', 'sample', 'mock',
        'your_key', 'your_password', 'your_token',
        'xxx', '****', '----',
    }

    # 变量名中的常量/配置模式
    CONSTANT_VAR_PATTERNS = [
        r'^[A-Z][A-Z0-9_]+$',  # 全大写: CONFIG_KEY
        r'example',  # 包含 example
        r'default',  # 包含 default
        r'^DEFAULT_',  # DEFAULT_ 前缀
        r'^EXAMPLE_',  # EXAMPLE_ 前缀
        r'^TEMPLATE_',  # TEMPLATE_ 前缀
        r'CONFIG$',  # 以 CONFIG 结尾
        r'SETTINGS$',  # 以 SETTINGS 结尾
    ]

    @property
    def name(self) -> str:
        return "ConstantFilter"

    def filter(self, finding: Finding, file_ctx: FileContext) -> bool:
        """
        检查是否应作为常量/默认值过滤

        参数:
            finding: 待检查的发现
            file_ctx: 文件上下文

        返回:
            True 如果应被过滤
        """
        # ---- 检查匹配字符串 ----
        matched_lower = finding.matched_string.lower()

        # 1. 匹配的值本身包含常量关键词
        for keyword in self.CONSTANT_KEYWORDS:
            if keyword in matched_lower:
                logger.debug(f"#{finding.rule.rule_id} 包含关键词 '{keyword}'，过滤")
                return True

        # ---- 检查变量名 ----
        var_name = finding.variable_name
        if not var_name:
            # 尝试从行内容提取
            var_name = self._extract_variable_name(finding.location.line_content)
        var_lower = var_name.lower()

        if not var_lower:
            return False

        # 2. 全大写变量名通常是配置常量
        if re.match(r'^[A-Z][A-Z0-9_]+$', var_name) and not var_lower.startswith('pass'):
            # 但 password/PASS 相关的全大写仍需保留
            if 'pass' not in var_lower and 'secret' not in var_lower and 'key' not in var_lower:
                logger.debug(f"#{finding.rule.rule_id} 全大写变量名 '{var_name}'，可能是配置常量")
                return True

        # 3. 变量名包含常量关键词
        for keyword in self.CONSTANT_KEYWORDS:
            if keyword in var_lower:
                logger.debug(f"#{finding.rule.rule_id} 变量名包含 '{keyword}'，过滤")
                return True

        # 4. 匹配常量变量名模式
        for pattern in self.CONSTANT_VAR_PATTERNS:
            if re.search(pattern, var_name, re.IGNORECASE):
                # 但排除安全相关的模式
                if not any(kw in var_lower for kw in ['password', 'secret', 'key', 'token']):
                    logger.debug(f"#{finding.rule.rule_id} 变量名匹配常量模式 '{pattern}'")
                    return True

        return False

    def _extract_variable_name(self, line_content: str) -> str:
        """
        从代码行提取变量名

        参数:
            line_content: 代码行

        返回:
            变量名或空字符串
        """
        if not line_content or '=' not in line_content:
            return ""

        left = line_content.split('=')[0].strip()
        left = left.split(':')[0].strip()  # 移除类型注解

        # 取最后一个标识符
        for part in left.split():
            part = part.strip('[]().,')
            if part.isidentifier():
                return part

        return ""