"""
AST 语法树检测器
================

基于 Python 抽象语法树的语义分析检测器。

与 PatternDetector 的区别:
- PatternDetector: 基于文本的正则匹配（快速但缺乏语义理解）
- ASTDetector: 基于代码结构分析（较慢但能理解代码语义）

检测能力:
1. 变量赋值追踪：识别硬编码赋值
2. 函数调用参数检测：检测敏感函数调用中的硬编码参数
3. 上下文语义分析：区分测试代码、配置代码和业务代码
4. 常量传播：追踪常量值在代码中的流动
"""

import ast
import logging
from typing import List, Optional, Set, Dict, Any, Tuple

from .base import BaseDetector
from ..core.models import DetectionRule, Finding
from ..core.context import FileContext

logger = logging.getLogger(__name__)


class ASTDetector(BaseDetector):
    """
    AST 语义分析检测器

    通过分析代码的抽象语法树，实现上下文感知的检测。
    能识别 PatternDetector 难以处理的复杂场景:
    - 变量名语义分析: 变量名为 'password' 的赋值
    - 函数调用上下文: connect(password="admin123")
    - 字符串拼接: DB_URL = "mysql://" + user + ":" + passwd + "@" + host
    """

    # 敏感变量名关键词（小写）
    SENSITIVE_VARIABLE_PATTERNS: Set[str] = {
        'password', 'passwd', 'pass', 'pwd', 'secret',
        'api_key', 'apikey', 'api_secret', 'apisecret',
        'access_key', 'secret_key', 'private_key',
        'token', 'auth_token', 'access_token', 'refresh_token',
        'jwt', 'jwt_secret', 'jwt_token',
        'db_url', 'database_url', 'dsn', 'connection_string',
        'credential', 'credentials', 'auth',
        'ssh_key', 'pgp_key', 'gpg_key',
    }

    # 敏感函数名（这些函数的参数可能包含敏感信息）
    SENSITIVE_FUNCTIONS: Set[str] = {
        'connect', 'login', 'auth', 'authenticate',
        'set_password', 'change_password',
        'encrypt', 'decrypt', 'sign',
        'hashed', 'hash_password',
    }

    @property
    def name(self) -> str:
        return "ASTDetector"

    def scan(
            self,
            file_ctx: FileContext,
            rule: DetectionRule
    ) -> List[Finding]:
        """
        执行 AST 语义分析扫描

        参数:
            file_ctx: 文件上下文（需要已加载 AST 树）
            rule: 检测规则

        返回:
            检测到的发现列表
        """
        findings = []

        # 确保 AST 树已加载
        if not file_ctx.ast_tree:
            self._load_ast(file_ctx)

        if not file_ctx.ast_tree:
            return findings

        try:
            # 使用 AST 访问者模式遍历语法树
            visitor = _SensitiveInfoVisitor(
                detector=self,
                file_ctx=file_ctx,
                rule=rule
            )
            visitor.visit(file_ctx.ast_tree)
            findings = visitor.findings

        except Exception as e:
            logger.error(f"AST 分析出错: {e}", exc_info=True)

        return findings

    def _load_ast(self, file_ctx: FileContext):
        """
        加载文件的 AST 语法树

        参数:
            file_ctx: 文件上下文
        """
        try:
            # 合并文件所有行
            source_code = '\n'.join(file_ctx.lines)
            file_ctx.ast_tree = ast.parse(source_code)
        except SyntaxError as e:
            logger.debug(f"文件语法错误，跳过 AST 分析: {e}")
            file_ctx.ast_tree = None
        except Exception as e:
            logger.error(f"AST 解析失败: {e}")
            file_ctx.ast_tree = None

    def supports_rule(self, rule: DetectionRule) -> bool:
        """
        ASTDetector 支持所有规则（提供语义增强）
        """
        return True


class _SensitiveInfoVisitor(ast.NodeVisitor):
    """
    AST 节点访问器（访问者模式）

    遍历 AST 树并检测敏感信息模式。
    主要关注:
    - Assign: 赋值语句
    - Call: 函数调用
    - AnnAssign: 带类型注解的赋值（Python 3.6+）
    """

    def __init__(
            self,
            detector: 'ASTDetector',
            file_ctx: FileContext,
            rule: DetectionRule
    ):
        self.detector = detector
        self.file_ctx = file_ctx
        self.rule = rule
        self.findings: List[Finding] = []

        # 当前分析的变量信息
        self.current_variable_name: str = ""

        # 已处理的节点集合（防重）
        self._processed_nodes: Set[int] = set()

    def visit_Assign(self, node: ast.Assign):
        """
        处理赋值语句: x = "value"

        检查:
        1. 变量名是否敏感（password, api_key 等）
        2. 赋的值是否匹配规则模式

        参数:
            node: 赋值语句 AST 节点
        """
        # 获取赋值目标（变量名）
        for target in node.targets:
            variable_name = self._get_target_name(target)
            if not variable_name:
                continue

            # 检查变量名是否敏感
            is_sensitive_var = self._is_sensitive_variable(variable_name)

            # 检查赋的值
            if isinstance(node.value, ast.Constant):
                value = node.value.value
                if isinstance(value, (str, bytes)):
                    if isinstance(value, bytes):
                        value = value.decode('utf-8', errors='ignore')

                    # 如果变量名敏感或值匹配规则，则创建发现
                    if is_sensitive_var or self._value_matches_rule(value):
                        self._add_finding(
                            node=node,
                            value=value,
                            variable_name=variable_name
                        )

            # 处理字符串拼接: x = "a" + "b"
            elif isinstance(node.value, ast.BinOp):
                concatenated = self._resolve_concatenation(node.value)
                if concatenated and self._value_matches_rule(concatenated):
                    self._add_finding(
                        node=node,
                        value=concatenated,
                        variable_name=variable_name
                    )

        # 继续遍历子节点
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign):
        """
        处理带类型注解的赋值: x: str = "value"

        参数:
            node: 注解赋值 AST 节点
        """
        if node.value is None:
            return

        # 获取变量名
        variable_name = self._get_target_name(node.target)
        if not variable_name:
            return

        is_sensitive_var = self._is_sensitive_variable(variable_name)

        # 检查赋的值
        if isinstance(node.value, ast.Constant):
            value = node.value.value
            if isinstance(value, (str, bytes)):
                if isinstance(value, bytes):
                    value = value.decode('utf-8', errors='ignore')

                if is_sensitive_var or self._value_matches_rule(value):
                    self._add_finding(
                        node=node,
                        value=value,
                        variable_name=variable_name
                    )

        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        """
        处理函数调用: connect(password="admin123")

        检查关键字参数是否包含敏感信息。

        参数:
            node: 函数调用 AST 节点
        """
        # 检查关键字参数
        for keyword in node.keywords:
            arg_name = keyword.arg

            # 参数名本身是否敏感
            if arg_name and self._is_sensitive_variable(arg_name):
                if isinstance(keyword.value, ast.Constant):
                    value = keyword.value.value
                    if isinstance(value, (str, bytes)):
                        if isinstance(value, bytes):
                            value = value.decode('utf-8', errors='ignore')

                        if self._value_matches_rule(value) or True:
                            # 函数调用参数中的敏感值
                            self._add_finding(
                                node=keyword,
                                value=value,
                                variable_name=arg_name,
                                extra_context="函数调用参数"
                            )

        # 检查函数名是否敏感
        func_name = self._get_func_name(node.func)
        if func_name and func_name.lower() in self.detector.SENSITIVE_FUNCTIONS:
            # 即使参数名不敏感，也检查位置参数
            for arg in node.args:
                if isinstance(arg, ast.Constant):
                    value = arg.value
                    if isinstance(value, (str, bytes)):
                        if isinstance(value, bytes):
                            value = value.decode('utf-8', errors='ignore')

                        if self._value_matches_rule(value):
                            self._add_finding(
                                node=arg,
                                value=value,
                                variable_name="",
                                extra_context=f"函数 '{func_name}' 的参数"
                            )

        self.generic_visit(node)

    def _get_target_name(self, target: ast.AST) -> str:
        """
        从赋值目标中提取变量名

        支持:
        - 简单变量: x
        - 属性: obj.attr -> "attr"
        - 下标: d['key'] -> "d"

        参数:
            target: 赋值目标 AST 节点

        返回:
            变量名字符串
        """
        if isinstance(target, ast.Name):
            return target.id
        elif isinstance(target, ast.Attribute):
            return target.attr
        elif isinstance(target, ast.Subscript):
            if isinstance(target.value, ast.Name):
                return target.value.id
        return ""

    def _get_func_name(self, func: ast.AST) -> str:
        """
        获取函数名

        参数:
            func: 函数 AST 节点

        返回:
            函数名字符串
        """
        if isinstance(func, ast.Name):
            return func.id
        elif isinstance(func, ast.Attribute):
            return func.attr
        return ""

    def _is_sensitive_variable(self, var_name: str) -> bool:
        """
        检查变量名是否为敏感关键词

        参数:
            var_name: 变量名

        返回:
            True 如果是敏感变量名
        """
        return var_name.lower() in self.detector.SENSITIVE_VARIABLE_PATTERNS

    def _value_matches_rule(self, value: str) -> bool:
        """
        检查值是否匹配规则的模式

        参数:
            value: 字符串值

        返回:
            True 如果匹配规则
        """
        if not self.rule.compiled_pattern:
            return False

        return bool(self.rule.compiled_pattern.search(value))

    def _resolve_concatenation(self, node: ast.BinOp) -> Optional[str]:
        """
        解析字符串拼接表达式

        例如: "mysql://" + user + ":" + pass
        仅处理全常量的拼接。

        参数:
            node: 二元操作 AST 节点

        返回:
            拼接后的字符串，无法完全解析返回 None
        """
        parts = []

        def collect_strings(n):
            if isinstance(n, ast.Constant) and isinstance(n.value, str):
                parts.append(n.value)
            elif isinstance(n, ast.BinOp) and isinstance(n.op, ast.Add):
                collect_strings(n.left)
                collect_strings(n.right)
            else:
                # 遇到非常量，无法完全解析
                raise ValueError("包含非常量")

        try:
            collect_strings(node)
            return ''.join(parts)
        except ValueError:
            return None

    def _add_finding(
            self,
            node: ast.AST,
            value: str,
            variable_name: str = "",
            extra_context: str = ""
    ):
        """
        添加一个 AST 检测发现

        参数:
            node: AST 节点
            value: 匹配的值
            variable_name: 变量名
            extra_context: 额外上下文信息
        """
        # 防止重复添加
        node_id = id(node)
        if node_id in self._processed_nodes:
            return
        self._processed_nodes.add(node_id)

        # 获取节点位置
        line_number = getattr(node, 'lineno', 1)
        col_offset = getattr(node, 'col_offset', 0)

        # 创建发现
        finding = self.detector.create_finding(
            rule=self.rule,
            file_ctx=self.file_ctx,
            line_number=line_number,
            column_offset=col_offset,
            matched_string=value,
            variable_name=variable_name,
            detection_method="AST"
        )

        # 如果有额外上下文，添加到修复建议中
        if extra_context:
            if not finding.fix_suggestion:
                finding.fix_suggestion = f"在 {extra_context} 中发现"

        self.findings.append(finding)