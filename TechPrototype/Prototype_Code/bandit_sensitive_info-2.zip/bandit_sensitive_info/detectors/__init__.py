"""
检测器模块
=========

实现多种敏感信息检测策略，每种检测器专注于不同的检测维度。

检测器类型:
- PatternDetector: 基于正则表达式的模式匹配（主力）
- ASTDetector: 基于Python AST的语义分析（上下文增强）
- EntropyDetector: 基于信息熵的高随机性字符串识别（辅助验证）

检测器遵循统一的 BaseDetector 接口，支持:
- 插拔式扩展：新增检测器只需继承基类
- 性能监控：每个检测器独立统计耗时
- 结果标准化：统一返回 Finding 对象
"""

from typing import Dict, Type, Optional

from .base import BaseDetector
from .pattern_detector import PatternDetector
from .ast_detector import ASTDetector
from .entropy_detector import EntropyDetector

# 检测器注册表
_DETECTOR_REGISTRY: Dict[str, Type[BaseDetector]] = {
    "PATTERN": PatternDetector,
    "AST": ASTDetector,
    "ENTROPY": EntropyDetector,
}


def get_detector(method: str) -> BaseDetector:
    """
    根据检测方法名称获取检测器实例（工厂函数）

    参数:
        method: 检测方法名 - "PATTERN", "AST", "ENTROPY"

    返回:
        对应的检测器实例

    抛出:
        ValueError: 当方法名无效时

    示例:
        >>> detector = get_detector("PATTERN")
        >>> findings = detector.scan(file_ctx, rule)
    """
    method_upper = method.upper()

    if method_upper not in _DETECTOR_REGISTRY:
        valid_methods = list(_DETECTOR_REGISTRY.keys())
        raise ValueError(
            f"不支持的检测方法: '{method}'，"
            f"有效方法: {valid_methods}"
        )

    return _DETECTOR_REGISTRY[method_upper]()


def register_detector(name: str, detector_class: Type[BaseDetector]):
    """
    注册自定义检测器（扩展接口）

    允许用户添加自定义检测器，无需修改框架代码。

    参数:
        name: 检测器名称（大写标识符）
        detector_class: 检测器类（必须继承 BaseDetector）

    示例:
        >>> class MyCustomDetector(BaseDetector):
        ...     def scan(self, file_ctx, rule):
        ...         # 自定义检测逻辑
        ...         return []
        >>> register_detector("MY_CUSTOM", MyCustomDetector)
    """
    if not issubclass(detector_class, BaseDetector):
        raise TypeError(
            f"检测器类必须继承 BaseDetector，"
            f"当前类型: {detector_class.__name__}"
        )
    _DETECTOR_REGISTRY[name.upper()] = detector_class


def list_detectors() -> Dict[str, str]:
    """
    列出所有已注册的检测器及其描述

    返回:
        检测器名称 -> 描述的字典
    """
    return {
        name: detector_cls.__doc__.split('\n')[0] if detector_cls.__doc__ else "无描述"
        for name, detector_cls in _DETECTOR_REGISTRY.items()
    }


__all__ = [
    "BaseDetector",
    "PatternDetector",
    "ASTDetector",
    "EntropyDetector",
    "get_detector",
    "register_detector",
    "list_detectors",
]

"""
用户代码 → plugin.py → _analyze_string_node()
                            │
                            ├─→ PatternDetector.scan()    ← 主力：80%+检测
                            │   （正则模式匹配）
                            │
                            ├─→ ASTDetector.scan()        ← 增强：语义分析
                            │   （AST语义分析）
                            │
                            └─→ EntropyDetector.scan()    ← 辅助：高熵识别
                                （熵值计算）
                                     │
                                     ▼
                              过滤器链（filters/）
                                     │
                                     ▼
                              最终 Finding 结果
"""