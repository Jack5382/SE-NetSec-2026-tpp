"""
检测器基类与接口定义
===================

定义所有检测器的统一接口和行为规范。
所有检测器必须继承此基类并实现 scan 方法。

设计原则:
- 单一职责：每个检测器只负责一种检测策略
- 无状态：检测器实例可在多线程中安全复用
- 可度量：内置性能统计，便于优化
"""

import time
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from collections import defaultdict

from ..core.models import DetectionRule, Finding, Location
from ..core.context import FileContext, ScanEnvironment

logger = logging.getLogger(__name__)


@dataclass
class DetectorStats:
    """
    检测器性能统计

    记录单个检测器的运行指标，用于:
    - 性能优化决策
    - 满足量化指标验证（扫描速度 >= 1000行/秒）
    - 定位性能瓶颈
    """
    # 调用统计
    total_calls: int = 0  # 总调用次数
    total_matches: int = 0  # 总匹配次数
    total_false_positives: int = 0  # 被过滤的误报数

    # 时间统计（秒）
    total_time_spent: float = 0.0  # 总耗时
    min_time: float = float('inf')  # 单次最小耗时
    max_time: float = 0.0  # 单次最大耗时

    # 缓存统计
    cache_hits: int = 0  # 缓存命中次数
    cache_misses: int = 0  # 缓存未命中次数

    def record_call(self, duration: float, matched: bool, was_false_positive: bool = False):
        """
        记录一次检测调用

        参数:
            duration: 本次调用耗时（秒）
            matched: 是否匹配到敏感信息
            was_false_positive: 最终是否被判定为误报
        """
        self.total_calls += 1
        self.total_time_spent += duration

        if duration < self.min_time:
            self.min_time = duration
        if duration > self.max_time:
            self.max_time = duration

        if matched:
            self.total_matches += 1
            if was_false_positive:
                self.total_false_positives += 1

    def get_average_time(self) -> float:
        """获取平均每次调用耗时（毫秒）"""
        if self.total_calls == 0:
            return 0.0
        return (self.total_time_spent / self.total_calls) * 1000

    def get_match_rate(self) -> float:
        """获取匹配率（匹配次数/总调用次数）"""
        if self.total_calls == 0:
            return 0.0
        return self.total_matches / self.total_calls

    def get_cache_hit_rate(self) -> float:
        """获取缓存命中率"""
        total = self.cache_hits + self.cache_misses
        if total == 0:
            return 0.0
        return self.cache_hits / total

    def to_dict(self) -> Dict[str, Any]:
        """导出统计信息"""
        return {
            "total_calls": self.total_calls,
            "total_matches": self.total_matches,
            "total_false_positives": self.total_false_positives,
            "avg_time_ms": round(self.get_average_time(), 4),
            "max_time_ms": round(self.max_time * 1000, 4),
            "match_rate": f"{self.get_match_rate():.2%}",
            "cache_hit_rate": f"{self.get_cache_hit_rate():.2%}",
        }


class BaseDetector(ABC):
    """
    检测器抽象基类

    所有检测器必须继承此类并实现 scan 方法。

    子类需要实现:
    - scan(): 核心检测逻辑

    子类可以覆盖:
    - _pre_scan(): 扫描前预处理
    - _post_scan(): 扫描后清理
    - name: 检测器名称属性

    使用示例:
        >>> class MyDetector(BaseDetector):
        ...     @property
        ...     def name(self):
        ...         return "my_detector"
        ...
        ...     def scan(self, file_ctx, rule):
        ...         # 实现检测逻辑
        ...         return []
    """

    # 类级别缓存（跨实例共享）
    _shared_cache: Dict[str, Any] = {}

    def __init__(self):
        """初始化检测器"""
        self.stats = DetectorStats()
        # 实例级别的本地缓存
        self._local_cache: Dict[str, Any] = {}

    @property
    def name(self) -> str:
        """检测器名称，默认使用类名"""
        return self.__class__.__name__

    @property
    def description(self) -> str:
        """检测器描述，从类文档字符串获取"""
        return self.__doc__.split('\n')[0] if self.__doc__ else "无描述"

    @abstractmethod
    def scan(
            self,
            file_ctx: FileContext,
            rule: DetectionRule
    ) -> List[Finding]:
        """
        执行检测扫描（抽象方法，子类必须实现）

        参数:
            file_ctx: 文件上下文，包含文件内容和元信息
            rule: 检测规则，定义检测模式和参数

        返回:
            检测到的敏感信息发现列表

        注意:
            - 如果未检测到任何敏感信息，应返回空列表而非 None
            - 此方法应该是无状态的，可安全并发调用
        """
        pass

    def scan_with_timing(
            self,
            file_ctx: FileContext,
            rule: DetectionRule
    ) -> List[Finding]:
        """
        带性能统计的扫描方法（模板方法模式）

        在扫描前后自动记录耗时和统计信息。
        子类应覆盖 scan() 而非此方法。

        参数:
            file_ctx: 文件上下文
            rule: 检测规则

        返回:
            检测结果列表
        """
        start_time = time.perf_counter()
        findings = []
        matched = False

        try:
            # 扫描前预处理
            self._pre_scan(file_ctx, rule)

            # 执行核心检测逻辑
            findings = self.scan(file_ctx, rule)

            matched = len(findings) > 0

        except Exception as e:
            logger.error(
                f"检测器 '{self.name}' 执行出错: {e}",
                exc_info=True
            )
            # 出错时返回空列表，不中断整体扫描
            findings = []

        finally:
            # 扫描后清理
            self._post_scan(file_ctx, rule)

            # 记录统计
            elapsed = time.perf_counter() - start_time
            self.stats.record_call(elapsed, matched)

        return findings

    def _pre_scan(self, file_ctx: FileContext, rule: DetectionRule):
        """
        扫描前的预处理钩子

        子类可覆盖此方法进行:
        - 规则预检查
        - 缓存预热
        - 资源准备

        参数:
            file_ctx: 文件上下文
            rule: 检测规则
        """
        pass

    def _post_scan(self, file_ctx: FileContext, rule: DetectionRule):
        """
        扫描后的清理钩子

        子类可覆盖此方法进行:
        - 缓存清理
        - 资源释放

        参数:
            file_ctx: 文件上下文
            rule: 检测规则
        """
        pass

    def supports_rule(self, rule: DetectionRule) -> bool:
        """
        检查此检测器是否支持指定规则

        默认实现检查规则是否有编译好的正则模式。
        子类可覆盖以实现更精细的判断逻辑。

        参数:
            rule: 检测规则

        返回:
            True 表示可以处理此规则
        """
        return rule.compiled_pattern is not None

    def create_finding(
            self,
            rule: DetectionRule,
            file_ctx: FileContext,
            line_number: int,
            column_offset: int,
            matched_string: str,
            variable_name: str = "",
            detection_method: str = "PATTERN"
    ) -> Finding:
        """
        创建标准化的 Finding 对象（工厂方法）

        封装 Finding 的创建逻辑，确保格式统一。

        参数:
            rule: 匹配的检测规则
            file_ctx: 文件上下文
            line_number: 匹配行号
            column_offset: 匹配列号
            matched_string: 匹配到的原始字符串
            variable_name: 关联的变量名
            detection_method: 检测方法标识

        返回:
            标准化的 Finding 对象
        """
        # 获取行内容
        line_content = file_ctx.get_line(line_number)

        # 创建位置对象
        location = Location(
            file_path=file_ctx.absolute_path or file_ctx.relative_path,
            line_number=line_number,
            column_offset=column_offset,
            line_content=line_content
        )

        # 创建发现对象
        finding = Finding(
            rule=rule,
            location=location,
            matched_string=matched_string,
            variable_name=variable_name,
            detection_method=detection_method
        )

        return finding

    def clear_cache(self):
        """清理缓存（用于释放内存）"""
        self._local_cache.clear()
        logger.debug(f"检测器 '{self.name}' 缓存已清理")

    def get_stats(self) -> Dict[str, Any]:
        """获取当前检测器的性能统计"""
        return {
            "name": self.name,
            "description": self.description,
            "stats": self.stats.to_dict()
        }

    def __repr__(self) -> str:
        return f"{self.name}(calls={self.stats.total_calls}, matches={self.stats.total_matches})"