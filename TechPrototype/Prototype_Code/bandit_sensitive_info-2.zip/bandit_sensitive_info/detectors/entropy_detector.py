# 熵值分析检测
"""
熵值分析检测器
==============

基于香农信息熵的高随机性字符串识别检测器。

原理:
- 正常文本（英文、代码）的熵值通常在 3.5-5.0 之间
- 高随机性数据（加密密钥、Base64 编码）的熵值通常在 5.5-7.5 之间
- 通过设定熵值阈值，可以识别出密钥、令牌等高随机性字符串

适用场景:
- Base64 编码的密钥: 熵值 >= 5.5
- 随机生成的令牌: 熵值 >= 6.0
- 加密私钥: 熵值 >= 6.5

注意:
- 熵值检测不是独立的检测手段，而是作为正则检测的辅助验证
- 单独使用熵值检测会产生较高误报率（如压缩数据、随机测试数据）
- 建议与 PatternDetector 配合使用（HYBRID 模式）
"""

import math
import logging
from collections import Counter
from typing import List, Optional

from .base import BaseDetector
from ..core.models import DetectionRule, Finding
from ..core.context import FileContext

logger = logging.getLogger(__name__)


class EntropyDetector(BaseDetector):
    """
    熵值分析检测器

    基于香农熵识别高随机性字符串。
    通常作为辅助检测手段，配合正则检测使用。

    熵值参考范围:
    - 3.0-4.0: 普通英文文本
    - 4.0-5.0: 代码/配置
    - 5.0-5.5: 混合内容（英文+数字+符号）
    - 5.5-6.5: Base64 编码数据/API 密钥
    - 6.5-8.0: 高强度加密密钥/随机令牌

    默认阈值: 4.5（平衡检出率和误报率）
    """

    # 评估用参考数据集
    REFERENCE_ENTROPY = {
        "english_text": 3.5,  # 纯英文文本
        "python_code": 4.2,  # Python 代码
        "base64_data": 5.8,  # Base64 编码数据
        "random_key_32": 6.2,  # 32字节随机密钥
        "random_key_64": 6.5,  # 64字节随机密钥
    }

    @property
    def name(self) -> str:
        return "EntropyDetector"

    def scan(
            self,
            file_ctx: FileContext,
            rule: DetectionRule
    ) -> List[Finding]:
        """
        执行熵值分析扫描

        仅处理启用了熵值检测的规则。
        扫描文件中所有较长字符串的熵值。

        参数:
            file_ctx: 文件上下文
            rule: 检测规则（需启用 entropy_analysis_enabled）

        返回:
            高熵值字符串的发现列表
        """
        findings = []

        # 熵值检测需要规则显式启用
        if not rule.entropy_analysis_enabled:
            return findings

        threshold = rule.entropy_threshold

        # ---- 逐行扫描 ----
        for line_num in range(1, file_ctx.total_lines + 1):
            line_content = file_ctx.get_line(line_num)

            if not line_content:
                continue

            # 提取当前行的所有字符串字面量
            strings = self._extract_string_literals(line_content)

            for string_value, col_offset in strings:
                # 跳过短字符串（太短无统计意义）
                if len(string_value) < 8:
                    continue

                # 跳过纯数字
                if string_value.isdigit():
                    continue

                # 检查排除条件
                if rule.is_excluded(string_value):
                    continue

                # 计算熵值
                entropy = self.calculate_shannon_entropy(string_value)

                if entropy >= threshold:
                    # 高熵值字符串
                    finding = self.create_finding(
                        rule=rule,
                        file_ctx=file_ctx,
                        line_number=line_num,
                        column_offset=col_offset,
                        matched_string=string_value,
                        detection_method="ENTROPY"
                    )

                    # 附加熵值信息到发现中
                    finding.fix_suggestion = (
                        f"检测到高熵值字符串 (熵值: {entropy:.2f})，"
                        f"可能是加密密钥或令牌"
                    )

                    findings.append(finding)

                    logger.debug(
                        f"高熵值字符串: 熵={entropy:.2f}, "
                        f"文件={file_ctx.relative_path}:{line_num}"
                    )

        return findings

    def _extract_string_literals(self, line: str) -> List[tuple]:
        """
        从一行代码中提取字符串字面量

        支持单引号、双引号、三引号字符串。

        参数:
            line: 代码行

        返回:
            (字符串值, 列偏移) 的列表
        """
        import re

        strings = []

        # 匹配引号字符串的正则
        # 支持: '...' , "..." , '''...''' , """..."""
        string_patterns = [
            # 双引号字符串（不含三引号）
            r'"([^"\\]*(?:\\.[^"\\]*)*)"',
            # 单引号字符串（不含三引号）
            r"'([^'\\]*(?:\\.[^'\\]*)*)'",
        ]

        for pattern in string_patterns:
            for match in re.finditer(pattern, line):
                value = match.group(1)
                # 排除太短的空格/符号字符串
                if len(value.strip()) >= 6:
                    strings.append((value, match.start()))

        return strings

    @staticmethod
    def calculate_shannon_entropy(data: str) -> float:
        """
        计算字符串的香农熵

        使用标准香农熵公式:
        H = -Σ p(x) * log2(p(x))

        其中 p(x) 是字符 x 在数据中出现的概率。

        参数:
            data: 输入字符串

        返回:
            香农熵值 (0.0-8.0)，值越高表示随机性越强

        示例:
            >>> EntropyDetector.calculate_shannon_entropy("abcabcabc")
            1.58  # 低熵，重复模式
            >>> EntropyDetector.calculate_shannon_entropy("xK9#mP2$vL5@nQ8")
            4.00  # 较高熵，混合字符
        """
        if not data:
            return 0.0

        length = len(data)

        # 统计每个字符出现的频率
        char_counts = Counter(data)

        # 计算熵值
        entropy = 0.0
        for count in char_counts.values():
            probability = count / length
            entropy -= probability * math.log2(probability)

        # 归一化到 0-8（8 = 完全随机 256 种字符均匀分布）
        # 理论上限 log2(256) = 8
        return min(entropy, 8.0)

    @staticmethod
    def calculate_relative_entropy(data: str) -> float:
        """
        计算相对熵值（0.0-1.0）

        相对熵值 = 香农熵 / log2(len(unique_chars))
        表示相对于字符集大小的随机程度。

        参数:
            data: 输入字符串

        返回:
            相对熵值 (0.0-1.0)，1.0 表示完全随机

        示例:
            >>> EntropyDetector.calculate_relative_entropy("abcabcabc")
            0.0  # 完全不随机
            >>> EntropyDetector.calculate_relative_entropy("Kx9mP2vL5nQ8")
            1.0  # 完全随机
        """
        if not data:
            return 0.0

        shannon_entropy = EntropyDetector.calculate_shannon_entropy(data)
        unique_chars = len(set(data))

        if unique_chars <= 1:
            return 0.0

        max_possible_entropy = math.log2(unique_chars)

        if max_possible_entropy == 0:
            return 0.0

        return shannon_entropy / max_possible_entropy

    @staticmethod
    def is_likely_key_or_token(data: str,
                               high_threshold: float = 5.5,
                               medium_threshold: float = 4.5) -> str:
        """
        判断字符串是否可能是密钥或令牌

        结合熵值和长度进行综合判断。

        参数:
            data: 输入字符串
            high_threshold: 高置信度阈值
            medium_threshold: 中置信度阈值

        返回:
            "HIGH": 极可能是密钥/令牌
            "MEDIUM": 可能是密钥/令牌
            "LOW": 不太可能是密钥/令牌

        示例:
            >>> EntropyDetector.is_likely_key_or_token("dGhpcyBpcyBhIGtleQ==")
            "MEDIUM"  # Base64 编码
            >>> EntropyDetector.is_likely_key_or_token("Hello World")
            "LOW"     # 普通文本
            >>> EntropyDetector.is_likely_key_or_token("Kx9mP2$vL5@nQ8#R3sT6")
            "HIGH"    # 高随机性
        """
        if len(data) < 8:
            return "LOW"

        entropy = EntropyDetector.calculate_shannon_entropy(data)

        # 综合判断
        if entropy >= high_threshold and len(data) >= 16:
            return "HIGH"
        elif entropy >= medium_threshold:
            return "MEDIUM"
        else:
            return "LOW"

    @staticmethod
    def get_entropy_profile(data: str) -> dict:
        """
        获取字符串的完整熵值分析结果

        参数:
            data: 输入字符串

        返回:
            包含多种熵值指标的字典
        """
        if not data:
            return {
                "shannon_entropy": 0.0,
                "relative_entropy": 0.0,
                "length": 0,
                "unique_chars": 0,
                "likely_type": "LOW",
            }

        return {
            "shannon_entropy": round(
                EntropyDetector.calculate_shannon_entropy(data), 4
            ),
            "relative_entropy": round(
                EntropyDetector.calculate_relative_entropy(data), 4
            ),
            "length": len(data),
            "unique_chars": len(set(data)),
            "likely_type": EntropyDetector.is_likely_key_or_token(data),
        }

    def supports_rule(self, rule: DetectionRule) -> bool:
        """
        EntropyDetector 仅在规则启用熵值分析时使用

        参数:
            rule: 检测规则

        返回:
            True 如果规则启用了 entropy_analysis_enabled
        """
        return rule.entropy_analysis_enabled