"""
正则模式检测器
=============

基于正则表达式的主力检测器，负责约 80% 的敏感信息检测任务。

检测策略:
1. 快速前缀过滤：利用规则前缀快速排除不匹配字符串
2. 主模式匹配：正则表达式精确匹配
3. 排除检查：排除关键词和排除模式过滤
4. 上下文增强：提取变量名等上下文信息

性能优化:
- 规则模式预编译（DetectionRule.compile_patterns()）
- 快速前缀过滤（避免不必要的正则匹配）
- 字符串长度预检
- 批量处理多行字符串
"""

import re
import logging
from typing import List, Optional

from .base import BaseDetector
from ..core.models import DetectionRule, Finding
from ..core.context import FileContext

logger = logging.getLogger(__name__)


class PatternDetector(BaseDetector):
    """
    正则模式匹配检测器

    这是最高效的检测器，基于预编译的正则表达式进行精确匹配。
    适用于具有固定格式的敏感信息检测:
    - AWS 密钥: AKIA[0-9A-Z]{16}
    - JWT 令牌: eyJ[A-Za-z0-9_-]+\\.eyJ...
    - 私钥标记: -----BEGIN.*PRIVATE KEY-----
    - 数据库 URL: (mysql|postgresql)://...
    """

    @property
    def name(self) -> str:
        return "PatternDetector"

    def scan(
            self,
            file_ctx: FileContext,
            rule: DetectionRule
    ) -> List[Finding]:
        """
        执行正则模式匹配扫描

        扫描流程:
        1. 验证规则有效性
        2. 逐行扫描文件内容
        3. 对每行执行模式匹配
        4. 收集所有匹配结果

        参数:
            file_ctx: 文件上下文
            rule: 检测规则

        返回:
            匹配到的发现列表
        """
        findings = []

        # ---- 验证规则有效性 ----
        if not rule.compiled_pattern:
            logger.debug(f"规则 '{rule.rule_id}' 没有编译模式，跳过")
            return findings

        # ---- 逐行扫描 ----
        for line_num in range(1, file_ctx.total_lines + 1):
            line_content = file_ctx.get_line(line_num)

            if not line_content:
                continue

            # 对当前行进行模式匹配
            line_findings = self._scan_line(
                file_ctx, rule, line_num, line_content
            )
            findings.extend(line_findings)

        return findings

    def _scan_line(
            self,
            file_ctx: FileContext,
            rule: DetectionRule,
            line_num: int,
            line_content: str
    ) -> List[Finding]:
        """
        对单行代码执行模式匹配

        参数:
            file_ctx: 文件上下文
            rule: 检测规则
            line_num: 当前行号
            line_content: 当前行内容

        返回:
            该行的发现列表
        """
        findings = []

        # 查找所有匹配
        for match in rule.compiled_pattern.finditer(line_content):
            matched_string = match.group()

            # ---- 快速前缀过滤 ----
            if not rule.matches_quick_filter(matched_string):
                continue

            # ---- 排除检查 ----
            if rule.is_excluded(matched_string):
                logger.debug(
                    f"规则 '{rule.rule_id}' 排除匹配: "
                    f"'{matched_string[:30]}...' "
                    f"在 {file_ctx.relative_path}:{line_num}"
                )
                continue

            # ---- 有效匹配：创建发现 ----
            # 计算列偏移
            column_offset = match.start()

            # 提取变量名
            variable_name = self._extract_variable_name(line_content, column_offset)

            # 创建发现
            finding = self.create_finding(
                rule=rule,
                file_ctx=file_ctx,
                line_number=line_num,
                column_offset=column_offset,
                matched_string=matched_string,
                variable_name=variable_name,
                detection_method="PATTERN"
            )

            findings.append(finding)

            logger.debug(
                f"检测到敏感信息: [{rule.category}] "
                f"{file_ctx.relative_path}:{line_num} "
                f"-> {rule.rule_id}"
            )

        return findings

    def _extract_variable_name(self, line_content: str, match_start: int) -> str:
        """
        从代码行提取变量名

        分析赋值语句，提取等号左侧的变量名。

        支持的模式:
        - 简单赋值: `var = "value"`
        - 属性赋值: `obj.attr = "value"`
        - 字典赋值: `dict['key'] = "value"`
        - 注释赋值: `var: str = "value"` (类型注解)

        参数:
            line_content: 代码行内容
            match_start: 匹配字符串的起始列位置

        返回:
            变量名，无法提取则返回空字符串
        """
        # 取等号前的部分
        before_match = line_content[:match_start]

        # 查找最近的等号
        eq_pos = before_match.rfind('=')
        if eq_pos == -1:
            # 等号可能在匹配之后（如函数调用参数）
            return ""

        # 提取等号左侧部分
        left_side = before_match[:eq_pos].strip()

        # 移除类型注解 (Python 3.6+)
        if ':' in left_side:
            # 处理 `var: str = "value"` 的情况
            left_side = left_side.split(':')[0].strip()

        if not left_side:
            return ""

        # 处理不同赋值形式
        # 1. 简单变量: var_name
        if left_side.isidentifier():
            return left_side

        # 2. 属性访问: obj.attr
        if '.' in left_side:
            return left_side.split('.')[-1].strip()

        # 3. 字典键: dict['key']
        if '[' in left_side and ']' in left_side:
            # 提取字典变量名
            dict_name = left_side.split('[')[0].strip()
            if dict_name.isidentifier():
                return dict_name

        # 4. 取最后一个单词
        words = left_side.split()
        if words:
            last_word = words[-1].strip('()[]{}.,;:')
            if last_word.isidentifier():
                return last_word

        return ""

    def supports_rule(self, rule: DetectionRule) -> bool:
        """
        PatternDetector 支持有编译模式的规则

        参数:
            rule: 检测规则

        返回:
            True 如果规则有编译好的正则模式
        """
        return rule.compiled_pattern is not None