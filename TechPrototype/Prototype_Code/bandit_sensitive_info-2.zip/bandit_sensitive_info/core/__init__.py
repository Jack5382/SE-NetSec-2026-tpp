"""
核心模块
=======

提供检测引擎的核心数据模型和基础设施。

包含:
- models: 所有数据模型定义（规则、发现、扫描结果等）
- enums: 标准化枚举类型
- context: 扫描上下文和文件分析
- result: 检测结果处理工具

示例:
    from bandit_sensitive_info.core import DetectionRule, ScanResult
"""

from .models import (
    DetectionRule,
    Finding,
    Location,
    ScanResult,
    ScanConfig,
    Severity,
    RuleSet,
)
from .enums import (
    SeverityLevel,
    ConfidenceLevel,
    DetectionMethod,
    SensitiveCategory,
    FilterType,
)
from .context import FileContext, VariableContext, ScanEnvironment
from .result import ResultProcessor

__all__ = [
    # 数据模型
    "DetectionRule",
    "Finding",
    "Location",
    "ScanResult",
    "ScanConfig",
    "Severity",
    "RuleSet",
    # 枚举
    "SeverityLevel",
    "ConfidenceLevel",
    "DetectionMethod",
    "SensitiveCategory",
    "FilterType",
    # 上下文
    "FileContext",
    "VariableContext",
    "ScanEnvironment",
    # 结果处理
    "ResultProcessor",
]

"""

├── __init__.py         ← 统一导出，简化外部导入
├── models.py           ← 数据模型基础（被所有模块依赖）
│   ├── Location        ← 代码位置
│   ├── Severity        ← 严重程度
│   ├── DetectionRule   ← 检测规则
│   ├── RuleSet         ← 规则集
│   ├── Finding         ← 检测发现
│   ├── ScanResult      ← 扫描结果
│   └── ScanConfig      ← 扫描配置
├── enums.py            ← 枚举定义（被 models 引用）
│   ├── SeverityLevel
│   ├── ConfidenceLevel
│   ├── DetectionMethod
│   ├── SensitiveCategory
│   ├── FilterType
│   └── ReportFormat
├── context.py          ← 扫描上下文（被检测器和过滤器使用）
│   ├── FileContext     ← 文件上下文
│   ├── VariableContext ← 变量上下文
│   └── ScanEnvironment ← 扫描环境
└── result.py           ← 结果处理（后处理阶段使用）
    ├── QualityGate     ← 质量门禁
    └── ResultProcessor ← 结果处理器
"""