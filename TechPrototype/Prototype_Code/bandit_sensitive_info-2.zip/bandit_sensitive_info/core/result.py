"""
检测结果封装与处理
==================

提供检测结果的后续处理功能:
- 结果去重与排序
- 质量门禁检查
- 结果导出为各种格式
- 与 Bandit 报告系统的集成
"""

import json
import csv
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

from .models import Finding, ScanResult, ScanConfig


@dataclass
class QualityGate:
    """
    质量门禁配置

    定义扫描结果的质量标准，用于 CI/CD 流程中的自动判断。
    不满足门禁的扫描应阻止代码合并。

    属性:
        max_fp_rate: 最大误报率 (默认 5%)
        max_fn_rate: 最大漏报率 (默认 3%)
        min_recall: 最小召回率/覆盖率 (默认 90%)
        max_high_severity: 允许的最大高危发现数 (0 = 不允许)
    """
    max_fp_rate: float = 0.05  # 5%
    max_fn_rate: float = 0.03  # 3%
    min_recall: float = 0.90  # 90%
    max_high_severity: int = 0  # 不允许任何高危发现

    def check(self, scan_result: ScanResult,
              expected_findings: List[Finding] = None,
              expected_non_findings: List = None) -> Dict[str, Any]:
        """
        检查扫描结果是否通过质量门禁

        参数:
            scan_result: 扫描结果
            expected_findings: 期望的发现（用于计算指标）
            expected_non_findings: 期望的非发现

        返回:
            检查结果字典，包含每个门禁的通过/失败状态
        """
        results = {
            "passed": True,
            "checks": {},
            "timestamp": datetime.now().isoformat(),
        }

        # 1. 高危发现数量检查
        high_count = scan_result.severity_counts.get("HIGH", 0)
        results["checks"]["high_severity_count"] = {
            "value": high_count,
            "threshold": f"<= {self.max_high_severity}",
            "passed": high_count <= self.max_high_severity
        }
        if not results["checks"]["high_severity_count"]["passed"]:
            results["passed"] = False

        # 2. 准确率指标检查（需要标注数据）
        if expected_findings and expected_non_findings:
            metrics = scan_result.calculate_accuracy_metrics(
                expected_findings, expected_non_findings
            )

            results["checks"]["false_positive_rate"] = {
                "value": f"{metrics['false_positive_rate']}%",
                "threshold": f"<= {self.max_fp_rate * 100}%",
                "passed": metrics["fp_rate_pass"]
            }

            results["checks"]["false_negative_rate"] = {
                "value": f"{metrics['false_negative_rate']}%",
                "threshold": f"<= {self.max_fn_rate * 100}%",
                "passed": metrics["fn_rate_pass"]
            }

            results["checks"]["recall"] = {
                "value": f"{metrics['recall']}%",
                "threshold": f">= {self.min_recall * 100}%",
                "passed": metrics["coverage_pass"]
            }

            if not all([
                metrics["fp_rate_pass"],
                metrics["fn_rate_pass"],
                metrics["coverage_pass"]
            ]):
                results["passed"] = False

        return results


@dataclass
class ResultProcessor:
    """
    结果处理器

    提供扫描结果的后续处理功能:
    - 结果去重（基于 finding_hash）
    - 结果排序（按严重程度、文件路径）
    - 结果过滤（按严重程度、分类、规则）
    - 结果导出（JSON、CSV 等格式）
    """

    # 输出目录
    output_dir: str = "./bandit_reports"

    # 质量门禁
    quality_gate: QualityGate = field(default_factory=QualityGate)

    def deduplicate(self, findings: List[Finding]) -> List[Finding]:
        """
        对发现列表去重

        基于 finding_hash 去重，保留第一次出现的发现。

        参数:
            findings: 原始发现列表

        返回:
            去重后的发现列表
        """
        seen = set()
        unique = []
        for finding in findings:
            if finding.finding_hash not in seen:
                seen.add(finding.finding_hash)
                unique.append(finding)

        return unique

    def sort_by_severity(self, findings: List[Finding]) -> List[Finding]:
        """
        按严重程度排序

        排序规则: HIGH > MEDIUM > LOW

        参数:
            findings: 发现列表

        返回:
            排序后的发现列表
        """
        severity_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
        return sorted(
            findings,
            key=lambda f: severity_order.get(f.rule.severity.level, 99)
        )

    def filter_by_severity(self, findings: List[Finding],
                           min_severity: str = "LOW") -> List[Finding]:
        """
        按严重程度过滤

        参数:
            findings: 发现列表
            min_severity: 最低严重程度 (HIGH/MEDIUM/LOW)

        返回:
            过滤后的发现列表
        """
        order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
        min_level = order.get(min_severity.upper(), 99)
        return [
            f for f in findings
            if order.get(f.rule.severity.level, 99) <= min_level
        ]

    def filter_by_category(self, findings: List[Finding],
                           categories: List[str]) -> List[Finding]:
        """
        按分类过滤

        参数:
            findings: 发现列表
            categories: 要保留的分类列表

        返回:
            过滤后的发现列表
        """
        return [f for f in findings if f.rule.category in categories]

    def export_json(self, scan_result: ScanResult,
                    filepath: Optional[str] = None) -> str:
        """
        导出为 JSON 格式

        参数:
            scan_result: 扫描结果
            filepath: 输出文件路径，None 则自动生成

        返回:
            输出文件的路径
        """
        if filepath is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = f"{self.output_dir}/scan_{timestamp}.json"

        # 确保目录存在
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)

        data = scan_result.to_dict()

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return filepath

    def export_csv(self, scan_result: ScanResult,
                   filepath: Optional[str] = None) -> str:
        """
        导出为 CSV 格式

        参数:
            scan_result: 扫描结果
            filepath: 输出文件路径

        返回:
            输出文件的路径
        """
        if filepath is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = f"{self.output_dir}/scan_{timestamp}.csv"

        Path(filepath).parent.mkdir(parents=True, exist_ok=True)

        # CSV 列定义
        fieldnames = [
            "rule_id", "category", "severity", "confidence",
            "file_path", "line_number", "column_offset",
            "sanitized_match", "variable_name",
            "detection_method", "fix_suggestion", "cwe_id"
        ]

        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for finding in scan_result.findings:
                writer.writerow({
                    "rule_id": finding.rule.rule_id,
                    "category": finding.rule.category,
                    "severity": finding.rule.severity.level,
                    "confidence": finding.rule.severity.confidence,
                    "file_path": finding.location.file_path,
                    "line_number": finding.location.line_number,
                    "column_offset": finding.location.column_offset,
                    "sanitized_match": finding.sanitized_match,
                    "variable_name": finding.variable_name,
                    "detection_method": finding.detection_method,
                    "fix_suggestion": finding.get_full_fix_suggestion(),
                    "cwe_id": finding.rule.cwe_id,
                })

        return filepath

    def export_summary_text(self, scan_result: ScanResult) -> str:
        """
        生成文本格式的扫描摘要

        参数:
            scan_result: 扫描结果

        返回:
            格式化的文本摘要
        """
        summary = scan_result.get_summary()

        lines = []
        lines.append("=" * 60)
        lines.append("  敏感信息扫描报告")
        lines.append("=" * 60)
        lines.append(f"  扫描耗时:  {summary['scan_duration_seconds']} 秒")
        lines.append(f"  扫描速度:  {summary['scan_speed_lines_per_second']} 行/秒")
        lines.append(f"  扫描文件:  {summary['total_files']} 个")
        lines.append(f"  扫描行数:  {summary['total_lines']} 行")
        lines.append("-" * 60)
        lines.append(f"  发现总数:  {summary['total_findings']}")
        lines.append(f"    高危:    {summary['severity_breakdown'].get('HIGH', 0)}")
        lines.append(f"    中危:    {summary['severity_breakdown'].get('MEDIUM', 0)}")
        lines.append(f"    低危:    {summary['severity_breakdown'].get('LOW', 0)}")
        lines.append(f"  过滤总数:  {summary['total_filtered']}")
        lines.append("-" * 60)

        if summary['top_rules']:
            lines.append("  触发最多的规则:")
            for rule_id, count in summary['top_rules'][:5]:
                lines.append(f"    - {rule_id}: {count} 次")

        lines.append("=" * 60)

        return "\n".join(lines)

    def generate_report(self, scan_result: ScanResult,
                        formats: List[str] = None) -> Dict[str, str]:
        """
        生成多种格式的报告

        参数:
            scan_result: 扫描结果
            formats: 输出格式列表，None 则输出 JSON + TXT

        返回:
            格式 -> 文件路径 的映射
        """
        if formats is None:
            formats = ["json", "txt"]

        output_files = {}

        for fmt in formats:
            fmt_lower = fmt.lower()
            if fmt_lower == "json":
                output_files["json"] = self.export_json(scan_result)
            elif fmt_lower == "csv":
                output_files["csv"] = self.export_csv(scan_result)
            elif fmt_lower == "txt":
                txt_path = f"{self.output_dir}/summary.txt"
                Path(txt_path).parent.mkdir(parents=True, exist_ok=True)
                text = self.export_summary_text(scan_result)
                with open(txt_path, 'w', encoding='utf-8') as f:
                    f.write(text)
                output_files["txt"] = txt_path

        return output_files