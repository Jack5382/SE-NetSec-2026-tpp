"""
扫描上下文与辅助数据结构
=========================

提供扫描过程中的环境信息、文件上下文和变量作用域追踪。
这些上下文对象在扫描过程中被创建和传递，
为检测器和过滤器提供必要的元信息。
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set
import ast


@dataclass
class FileContext:
    """
    文件上下文信息

    记录当前正在扫描文件的完整元信息，
    包括路径、内容、AST 树和特殊标记检查。

    用途:
    - 为检测器提供代码内容访问
    - 为过滤器提供文件属性判断（是否测试文件等）
    - 提供 #nosec 注释检查
    """
    # 文件路径
    absolute_path: str = ""  # 绝对路径
    relative_path: str = ""  # 相对于项目根目录的路径

    # 文件内容
    lines: List[str] = field(default_factory=list)  # 按行存储的文件内容
    total_lines: int = 0  # 总行数

    # 文件属性
    is_test_file: bool = False  # 是否为测试文件
    is_generated: bool = False  # 是否为自动生成的文件

    # AST 树（延迟加载）
    ast_tree: Optional[ast.AST] = None

    # nosec 行号缓存（避免重复字符串查找）
    _nosec_lines: Set[int] = field(default_factory=set, repr=False)

    def get_line(self, line_number: int) -> str:
        """
        获取指定行的内容

        参数:
            line_number: 行号（从 1 开始计数）

        返回:
            该行的字符串内容，行号越界返回空字符串
        """
        if 0 < line_number <= len(self.lines):
            return self.lines[line_number - 1]
        return ""

    def get_line_range(self, start: int, end: int) -> List[str]:
        """
        获取指定行范围的内容

        参数:
            start: 起始行号（包含）
            end: 结束行号（包含）

        返回:
            行内容列表
        """
        if start > end or start < 1:
            return []
        end = min(end, len(self.lines))
        start = max(start, 1)
        return self.lines[start - 1:end]

    def get_context_lines(self, line_number: int, before: int = 2, after: int = 2) -> str:
        """
        获取指定行及其上下文

        用于生成可读的报告片段。

        参数:
            line_number: 中心行号
            before: 向前取几行
            after: 向后取几行

        返回:
            带行号的上下文代码片段
        """
        start = max(1, line_number - before)
        end = min(len(self.lines), line_number + after)

        result = []
        for i in range(start, end + 1):
            prefix = ">>> " if i == line_number else "    "
            result.append(f"{prefix}{i:4d}: {self.lines[i - 1]}")

        return "\n".join(result)

    def is_filtered_by_nosec(self, line_number: int) -> bool:
        """
        检查指定行是否被 #nosec 标记为忽略

        支持两种格式:
        - 行内标记: `password = "xxx"  # nosec`
        - 前一行标记: `# nosec` (下一行被忽略)

        参数:
            line_number: 行号（从 1 开始）

        返回:
            如果该行应被 nosec 忽略则返回 True
        """
        # 检查缓存
        if line_number in self._nosec_lines:
            return True

        # 检查当前行
        if self._line_has_nosec(line_number):
            self._nosec_lines.add(line_number)
            return True

        # 检查前一行（注释形式的 nosec 通常在前一行）
        if line_number > 1 and self._line_has_nosec(line_number - 1):
            # 确认前一行是纯注释行（不是行内注释）
            prev_line = self.get_line(line_number - 1).strip()
            if prev_line.startswith('#'):
                self._nosec_lines.add(line_number)
                return True

        return False

    def _line_has_nosec(self, line_number: int) -> bool:
        """检查单行是否包含 nosec 标记"""
        line = self.get_line(line_number)
        return "# nosec" in line.lower() or "#nosec" in line.lower()

    def load_content(self, file_path: Optional[str] = None):
        """
        加载文件内容

        从磁盘读取文件并填充 lines 列表。

        参数:
            file_path: 文件路径，默认使用 absolute_path
        """
        path = file_path or self.absolute_path
        if not path:
            return

        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                self.lines = f.readlines()
            # 去除行尾的换行符
            self.lines = [line.rstrip('\n\r') for line in self.lines]
            self.total_lines = len(self.lines)
        except Exception:
            self.lines = []
            self.total_lines = 0

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "absolute_path": self.absolute_path,
            "relative_path": self.relative_path,
            "total_lines": self.total_lines,
            "is_test_file": self.is_test_file,
            "is_generated": self.is_generated,
        }


@dataclass
class VariableContext:
    """
    变量上下文信息

    追踪单个变量的定义、赋值来源和值变化历史。
    用于判断硬编码的值是否真的来自代码字面量，
    还是从环境变量/配置文件等安全来源获取。

    属性:
        name: 变量名
        definition_line: 变量首次定义的行号
        current_value: 当前值（最后一次赋值）
        value_history: 所有赋值历史
        source: 值来源 - HARDCODED/ENV_VAR/CONFIG_FILE/FUNCTION_CALL
    """
    name: str = ""
    definition_line: int = 0
    current_value: Optional[str] = None
    value_history: List[str] = field(default_factory=list)
    source: str = "HARDCODED"

    # 安全来源标记
    _SAFE_SOURCES = {"ENV_VAR", "CONFIG_FILE", "SECRET_MANAGER", "VAULT"}

    def is_from_safe_source(self) -> bool:
        """检查变量是否来自安全的来源"""
        return self.source in self._SAFE_SOURCES

    def add_assignment(self, value: str, line_number: int, source: str = "HARDCODED"):
        """
        记录变量的一次赋值

        参数:
            value: 赋的值
            line_number: 赋值行号
            source: 值来源标识
        """
        if not self.definition_line:
            self.definition_line = line_number
        self.current_value = value
        self.value_history.append(value)
        if source in self._SAFE_SOURCES:
            self.source = source

    def has_value(self, value: str) -> bool:
        """检查变量历史上是否被赋予过某个值"""
        return value in self.value_history

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "name": self.name,
            "definition_line": self.definition_line,
            "current_value_masked": "***" if self.current_value else None,
            "source": self.source,
            "is_safe": self.is_from_safe_source(),
        }


@dataclass
class ScanEnvironment:
    """
    扫描环境配置

    记录整体扫描运行时的环境和状态。
    作为全局单例在扫描过程中传递，维护跨文件的状态。

    主要职责:
    - 维护全局变量符号表
    - 跟踪已扫描文件（防重复）
    - 缓存加载的规则
    - 记录环境元信息
    """
    # 路径信息
    project_root: str = ""
    working_directory: str = field(default_factory=os.getcwd)

    # 版本信息
    python_version: str = ""
    bandit_version: str = ""
    plugin_version: str = ""

    # 操作系统
    os_type: str = field(default_factory=lambda: os.name)

    # 全局状态
    global_variables: Dict[str, VariableContext] = field(default_factory=dict)
    scanned_files: Set[str] = field(default_factory=set)
    cached_rules: Dict[str, 'RuleSet'] = field(default_factory=dict)

    # 统计
    total_files_scanned: int = 0
    total_lines_scanned: int = 0

    def register_variable(self, name: str, var: VariableContext):
        """注册全局变量追踪"""
        self.global_variables[name] = var

    def get_variable(self, name: str) -> Optional[VariableContext]:
        """获取变量上下文"""
        return self.global_variables.get(name)

    def is_file_scanned(self, file_path: str) -> bool:
        """检查文件是否已扫描"""
        return file_path in self.scanned_files

    def mark_file_scanned(self, file_path: str):
        """标记文件为已扫描"""
        self.scanned_files.add(file_path)
        self.total_files_scanned += 1

    def cache_rule_set(self, name: str, rule_set: 'RuleSet'):
        """缓存规则集"""
        self.cached_rules[name] = rule_set

    def get_cached_rule_set(self, name: str) -> Optional['RuleSet']:
        """获取缓存的规则集"""
        return self.cached_rules.get(name)

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "project_root": self.project_root,
            "python_version": self.python_version,
            "bandit_version": self.bandit_version,
            "plugin_version": self.plugin_version,
            "total_files_scanned": self.total_files_scanned,
            "total_lines_scanned": self.total_lines_scanned,
            "tracked_variables": len(self.global_variables),
            "cached_rule_sets": len(self.cached_rules),
        }