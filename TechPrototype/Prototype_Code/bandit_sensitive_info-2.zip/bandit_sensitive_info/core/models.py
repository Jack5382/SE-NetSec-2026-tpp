
"""
核心数据模型定义
================

定义了整个项目中使用的所有核心数据结构，
包括规则定义、检测结果、扫描配置等。

所有数据类都支持:
- 类型安全: 使用 Python 类型注解
- 序列化: to_dict() 方法用于 JSON 序列化
- 验证: __post_init__() 自动校验数据完整性
- Bandit 兼容: 提供到 Bandit 格式的转换方法
"""

import hashlib
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Pattern, Set, Union


# ============================================================================
# 基础位置与严重程度
# ============================================================================

@dataclass
class Location:
    """
    代码位置信息

    精确定位敏感信息在源代码中的位置。
    行号从 1 开始，列号从 0 开始（与 Bandit 保持一致）。

    属性:
        file_path: 文件路径，如 "src/auth/login.py"
        line_number: 行号，从 1 开始计数
        column_offset: 列号，从 0 开始计数
        line_content: 代码行内容，用于报告中展示
    """
    file_path: str
    line_number: int
    column_offset: int
    line_content: str = ""

    def __post_init__(self):
        """验证位置信息的有效性"""
        if self.line_number < 1:
            raise ValueError(f"行号必须大于 0，当前值: {self.line_number}")
        if self.column_offset < 0:
            raise ValueError(f"列号不能为负数，当前值: {self.column_offset}")

    def to_bandit_format(self) -> Dict[str, Any]:
        """
        转换为 Bandit 标准格式的位置字典

        返回:
            Bandit 兼容的位置信息字典，支持原生报告输出
        """
        return {
            "filename": self.file_path,
            "line_number": self.line_number,
            "col_offset": self.column_offset,
            "line": self.line_content
        }

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "file_path": self.file_path,
            "line_number": self.line_number,
            "column_offset": self.column_offset,
            "line_content": self.line_content
        }

    def __str__(self) -> str:
        """可读的字符串表示"""
        return f"{self.file_path}:{self.line_number}:{self.column_offset}"


@dataclass
class Severity:
    """
    严重程度定义

    对标 Bandit 的三级严重度体系，同时支持 CVSS 评分的精确映射。
    用于企业级风险评估和合规检查。

    属性:
        level: 严重程度等级 - HIGH, MEDIUM, LOW
        cvss_score: CVSS 评分 (0.0-10.0)，用于量化风险
        confidence: 置信度等级 - HIGH, MEDIUM, LOW

    CVSS 映射参考:
        HIGH:   7.0-10.0 (关键/高危漏洞)
        MEDIUM: 4.0-6.9  (中危漏洞)
        LOW:    0.1-3.9  (低危/信息泄露)
    """
    level: str
    cvss_score: float = 0.0
    confidence: str = "MEDIUM"

    # 默认 CVSS 评分映射
    _DEFAULT_CVSS = {"HIGH": 7.5, "MEDIUM": 5.0, "LOW": 2.5}
    # 有效的严重程度等级
    _VALID_LEVELS = {"HIGH", "MEDIUM", "LOW"}

    def __post_init__(self):
        """验证严重程度并自动设置默认 CVSS 评分"""
        # 标准化等级为大写
        self.level = self.level.upper()

        # 验证等级
        if self.level not in self._VALID_LEVELS:
            raise ValueError(
                f"无效的严重程度: {self.level}，"
                f"有效值: {self._VALID_LEVELS}"
            )

        # 验证置信度
        if self.confidence.upper() not in self._VALID_LEVELS:
            raise ValueError(
                f"无效的置信度: {self.confidence}，"
                f"有效值: {self._VALID_LEVELS}"
            )

        # 自动设置默认 CVSS 评分
        if self.cvss_score == 0.0:
            self.cvss_score = self._DEFAULT_CVSS[self.level]

        # 验证 CVSS 范围
        if not (0.0 <= self.cvss_score <= 10.0):
            raise ValueError(f"CVSS 评分必须在 0.0-10.0 之间，当前值: {self.cvss_score}")

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "level": self.level,
            "cvss_score": self.cvss_score,
            "confidence": self.confidence
        }

    def is_critical(self) -> bool:
        """判断是否为关键风险 (CVSS >= 9.0)"""
        return self.cvss_score >= 9.0


# ============================================================================
# 检测规则
# ============================================================================

@dataclass
class DetectionRule:
    """
    检测规则定义

    单个敏感信息检测规则的核心数据结构。
    支持从 YAML 配置反序列化，包含检测模式、排除条件、修复建议等完整信息。

    规则组成:
    - 标识信息: rule_id, description, category
    - 检测模式: pattern, compiled_pattern, ast_node_types
    - 误报过滤: exclude_keywords, exclude_patterns
    - 熵值检测: entropy_analysis_enabled, entropy_threshold
    - 修复指引: fix_suggestion, fix_example, cwe_id
    """
    # ---------- 规则标识 ----------
    rule_id: str  # 规则唯一 ID，如 "AWS_ACCESS_KEY"
    description: str = ""  # 规则描述
    category: str = ""  # 分类: password/api_key/jwt_token 等

    # ---------- 严重程度 ----------
    severity: Severity = field(default_factory=lambda: Severity("MEDIUM"))

    # ---------- 检测模式 ----------
    pattern: Optional[str] = None  # 正则表达式（字符串形式）
    compiled_pattern: Optional[Pattern] = field(default=None, repr=False)  # 编译后的正则
    ast_node_types: List[str] = field(default_factory=list)  # AST 节点类型

    # ---------- 误报过滤 ----------
    exclude_keywords: List[str] = field(default_factory=list)  # 排除关键词
    exclude_patterns: List[str] = field(default_factory=list)  # 排除正则
    compiled_exclude_patterns: List[Pattern] = field(default_factory=list, repr=False)

    # ---------- 熵值检测 ----------
    entropy_analysis_enabled: bool = False  # 是否启用熵值分析
    entropy_threshold: float = 4.5  # 熵值阈值 (香农熵, 通常 4.5 以上为高随机性)

    # ---------- 修复指引 ----------
    fix_suggestion: str = ""  # 修复建议文本
    fix_example: str = ""  # 修复代码示例
    cwe_id: str = ""  # CWE 编号
    owasp_category: str = ""  # OWASP 分类

    # ---------- 性能优化 ----------
    _quick_prefix: str = field(default="", repr=False)  # 快速前缀过滤

    def __post_init__(self):
        """初始化后处理"""
        if self.cwe_id and not self.cwe_id.startswith("CWE-"):
            self.cwe_id = f"CWE-{self.cwe_id}"

    def compile_patterns(self):
        """
        编译所有正则表达式模式

        在规则加载后调用此方法以提高运行时性能。
        将字符串形式的正则编译为 Pattern 对象，避免重复编译。

        抛出:
            ValueError: 当正则表达式语法错误时
        """
        # 编译主检测模式
        if self.pattern:
            try:
                self.compiled_pattern = re.compile(self.pattern)
                # 提取快速前缀（用于预筛选优化）
                self._quick_prefix = self._extract_prefix(self.pattern)
            except re.error as e:
                raise ValueError(
                    f"规则 '{self.rule_id}' 的模式编译失败: {e}\n"
                    f"模式: {self.pattern}"
                )

        # 编译排除模式
        self.compiled_exclude_patterns = []
        for i, exclude_pattern in enumerate(self.exclude_patterns):
            try:
                self.compiled_exclude_patterns.append(
                    re.compile(exclude_pattern, re.IGNORECASE)
                )
            except re.error as e:
                raise ValueError(
                    f"规则 '{self.rule_id}' 的排除模式 #{i + 1} 编译失败: {e}\n"
                    f"模式: {exclude_pattern}"
                )

    @staticmethod
    def _extract_prefix(pattern: str) -> str:
        """
        从正则表达式中提取字面前缀用于快速过滤

        例如:
            "AKIA[0-9A-Z]{16}" -> "AKIA"
            "eyJ[A-Za-z0-9_-]+\\.eyJ" -> "eyJ"
            "(password|passwd)\\s*=" -> "" (无法提取)

        参数:
            pattern: 正则表达式字符串

        返回:
            字面前缀，如果无法提取则返回空字符串
        """
        prefix_chars = []
        for char in pattern:
            if char.isalnum():
                prefix_chars.append(char)
            elif char in r'\.-_':
                prefix_chars.append(char)
            else:
                break

        prefix = ''.join(prefix_chars)
        # 只保留长度 >= 3 的前缀（太短无过滤效果）
        return prefix if len(prefix) >= 3 else ""

    def matches_quick_filter(self, value: str) -> bool:
        """
        快速前缀过滤：检查字符串是否可能匹配此规则

        用于在正则匹配前进行快速预筛选，大幅提高扫描速度。

        参数:
            value: 待检查的字符串

        返回:
            True 表示可能匹配，需要进一步正则检查
            False 表示肯定不匹配，可以跳过
        """
        if not self._quick_prefix:
            return True  # 无快速前缀，无法预判
        return value.startswith(self._quick_prefix)

    def is_excluded(self, value: str) -> bool:
        """
        检查字符串是否应被排除

        组合检查排除关键词和排除模式。

        参数:
            value: 待检查的字符串

        返回:
            True 表示应被过滤掉
        """
        value_lower = value.lower()

        # 检查排除关键词
        for keyword in self.exclude_keywords:
            if keyword.lower() in value_lower:
                return True

        # 检查排除模式
        for exclude_pattern in self.compiled_exclude_patterns:
            if exclude_pattern.search(value):
                return True

        return False

    def to_dict(self) -> Dict[str, Any]:
        """转换为可序列化的字典"""
        return {
            "rule_id": self.rule_id,
            "description": self.description,
            "category": self.category,
            "severity": self.severity.to_dict(),
            "pattern": self.pattern,
            "exclude_keywords": self.exclude_keywords,
            "exclude_patterns": self.exclude_patterns,
            "entropy_analysis_enabled": self.entropy_analysis_enabled,
            "entropy_threshold": self.entropy_threshold,
            "fix_suggestion": self.fix_suggestion,
            "fix_example": self.fix_example,
            "cwe_id": self.cwe_id,
            "owasp_category": self.owasp_category,
        }


@dataclass
class RuleSet:
    """
    规则集定义

    管理一组相关的检测规则，支持从 YAML 文件批量加载。
    规则集可以按需启用/禁用，实现灵活的检测策略配置。

    属性:
        name: 规则集名称，如 "api_keys", "passwords"
        description: 规则集描述
        enabled_by_default: 是否默认启用（用户可覆盖）
        rules: 包含的规则列表
    """
    name: str = ""
    description: str = ""
    enabled_by_default: bool = True
    rules: List[DetectionRule] = field(default_factory=list)

    def get_enabled_rules(self) -> List[DetectionRule]:
        """
        获取所有有效的规则（有检测模式的规则）

        返回:
            有效的规则列表
        """
        return [
            rule for rule in self.rules
            if rule.compiled_pattern or rule.entropy_analysis_enabled
        ]

    def get_rules_by_category(self, category: str) -> List[DetectionRule]:
        """
        按分类获取规则

        参数:
            category: 规则分类名称

        返回:
            匹配的规则列表
        """
        return [rule for rule in self.rules if rule.category == category]

    def get_high_severity_rules(self) -> List[DetectionRule]:
        """
        获取所有高危规则

        返回:
            HIGH 级别的规则列表
        """
        return [rule for rule in self.rules if rule.severity.level == "HIGH"]

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "name": self.name,
            "description": self.description,
            "enabled_by_default": self.enabled_by_default,
            "rule_count": len(self.rules),
            "rules": [rule.to_dict() for rule in self.rules]
        }

    def __len__(self) -> int:
        """规则数量"""
        return len(self.rules)

    def __iter__(self):
        """迭代规则"""
        return iter(self.rules)


# ============================================================================
# 检测结果
# ============================================================================

@dataclass
class Finding:
    """
    敏感信息发现结果

    代表检测到的一个敏感信息实例，包含完整的上下文信息。
    自动计算唯一哈希用于去重。

    属性:
        rule: 触发此发现的检测规则
        location: 代码中的位置
        matched_string: 匹配到的完整字符串（敏感信息原文）
        sanitized_match: 脱敏后的字符串（用于安全输出）
        variable_name: 关联的变量名
        detection_method: 检测方法 - PATTERN/AST/ENTROPY/HYBRID
        detected_at: 检测时间戳
        fix_suggestion: 修复建议（可覆盖规则默认建议）
        finding_hash: 发现的唯一哈希值（自动计算）
    """
    rule: DetectionRule
    location: Location
    matched_string: str = ""
    sanitized_match: str = ""
    variable_name: str = ""
    detection_method: str = "PATTERN"
    detected_at: datetime = field(default_factory=datetime.now)
    fix_suggestion: str = ""
    finding_hash: str = field(init=False)
    is_nosec_flagged: bool = False

    def __post_init__(self):
        """初始化后自动计算唯一哈希并生成脱敏字符串"""
        self.finding_hash = self._calculate_hash()

        # 如果没有提供脱敏字符串，自动生成
        if not self.sanitized_match and self.matched_string:
            self.sanitized_match = self._generate_sanitized()

    def _calculate_hash(self) -> str:
        """
        基于位置和匹配内容计算唯一哈希

        用于去重：同一位置的同一敏感信息只报告一次。

        返回:
            SHA256 哈希的前 16 位十六进制字符串
        """
        hash_input = (
            f"{self.location.file_path}:"
            f"{self.location.line_number}:"
            f"{self.matched_string}"
        )
        return hashlib.sha256(hash_input.encode()).hexdigest()[:16]

    def _generate_sanitized(self) -> str:
        """
        自动生成脱敏字符串

        脱敏规则:
        - 长度 <= 6: 显示首1字符 + ***
        - 长度 7-15: 显示首3字符 + *** + 尾2字符
        - 长度 > 15: 显示首5字符 + *** + 尾4字符

        返回:
            脱敏后的字符串
        """
        value = self.matched_string
        length = len(value)

        if length <= 6:
            return value[:1] + "***"
        elif length <= 15:
            return value[:3] + "***" + value[-2:]
        else:
            return value[:5] + "***" + value[-4:]

    def get_full_fix_suggestion(self) -> str:
        """
        获取完整的修复建议

        优先使用发现级别的建议，否则使用规则级别的默认建议。

        返回:
            修复建议文本
        """
        return self.fix_suggestion or self.rule.fix_suggestion

    def get_code_example(self) -> str:
        """
        获取修复代码示例

        返回:
            修复代码示例
        """
        return self.rule.fix_example

    def to_bandit_result(self) -> Dict[str, Any]:
        """
        转换为 Bandit 兼容的结果格式

        返回:
            Bandit 原生报告系统可识别的结果字典
        """
        return {
            "filename": self.location.file_path,
            "line_number": self.location.line_number,
            "col_offset": self.location.column_offset,
            "code": self.location.line_content,
            "issue_severity": self.rule.severity.level,
            "issue_confidence": self.rule.severity.confidence,
            "issue_text": f"[{self.rule.category}] {self.rule.description}",
            "test_id": self.rule.rule_id,
            "test_name": self.rule.description,
            "more_info": self.get_full_fix_suggestion(),
            "cwe_id": self.rule.cwe_id,
        }

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "finding_hash": self.finding_hash,
            "rule_id": self.rule.rule_id,
            "category": self.rule.category,
            "severity": self.rule.severity.level,
            "location": self.location.to_dict(),
            "matched_string_sanitized": self.sanitized_match,
            "variable_name": self.variable_name,
            "detection_method": self.detection_method,
            "detected_at": self.detected_at.isoformat(),
            "fix_suggestion": self.get_full_fix_suggestion(),
            "fix_example": self.get_code_example(),
            "cwe_id": self.rule.cwe_id,
        }


# ============================================================================
# 扫描结果与配置
# ============================================================================

@dataclass
class ScanResult:
    """
    完整扫描结果

    汇总一轮扫描的所有发现和统计信息。
    支持增量添加发现、实时统计和准确率计算。

    包含:
    - 扫描发现列表
    - 性能统计（速度、内存）
    - 质量指标（误报率、漏报率）
    - 按严重程度/规则的分布统计
    """
    # 使用的规则集
    rule_set: RuleSet = field(default_factory=RuleSet)

    # 所有发现
    findings: List[Finding] = field(default_factory=list)

    # ---------- 时间统计 ----------
    scan_start_time: datetime = field(default_factory=datetime.now)
    scan_end_time: Optional[datetime] = None

    # ---------- 规模统计 ----------
    total_files_scanned: int = 0
    total_lines_scanned: int = 0

    # ---------- 发现统计 ----------
    total_findings: int = 0
    severity_counts: Dict[str, int] = field(default_factory=lambda: {
        "HIGH": 0, "MEDIUM": 0, "LOW": 0
    })
    rule_counts: Dict[str, int] = field(default_factory=dict)

    # ---------- 过滤统计 ----------
    total_filtered: int = 0
    filter_reasons: Dict[str, int] = field(default_factory=dict)

    def add_finding(self, finding: Finding):
        """
        添加一个发现并自动更新统计信息

        参数:
            finding: 敏感信息发现结果
        """
        self.findings.append(finding)
        self.total_findings += 1

        # 更新严重程度统计
        severity = finding.rule.severity.level
        self.severity_counts[severity] = self.severity_counts.get(severity, 0) + 1

        # 更新规则统计
        rule_id = finding.rule.rule_id
        self.rule_counts[rule_id] = self.rule_counts.get(rule_id, 0) + 1

    def record_filtered(self, reason: str):
        """
        记录一个被过滤的发现

        参数:
            reason: 过滤原因（如 "comment", "nosec", "test_code"）
        """
        self.total_filtered += 1
        self.filter_reasons[reason] = self.filter_reasons.get(reason, 0) + 1

    def mark_complete(self):
        """标记扫描完成，记录结束时间"""
        self.scan_end_time = datetime.now()

    def get_duration_seconds(self) -> float:
        """
        获取扫描耗时（秒）

        返回:
            扫描持续时间，如果未结束则计算到当前时间
        """
        end = self.scan_end_time or datetime.now()
        return (end - self.scan_start_time).total_seconds()

    def get_scan_speed(self) -> float:
        """
        计算扫描速度（行/秒）

        返回:
            每秒扫描的行数，0 表示无法计算
        """
        duration = self.get_duration_seconds()
        if duration > 0:
            return self.total_lines_scanned / duration
        return 0.0

    def get_summary(self) -> Dict[str, Any]:
        """
        获取扫描摘要信息

        返回:
            包含所有关键统计的字典
        """
        return {
            "scan_duration_seconds": round(self.get_duration_seconds(), 2),
            "scan_speed_lines_per_second": round(self.get_scan_speed(), 2),
            "total_files": self.total_files_scanned,
            "total_lines": self.total_lines_scanned,
            "total_findings": self.total_findings,
            "total_filtered": self.total_filtered,
            "severity_breakdown": dict(self.severity_counts),
            "filter_breakdown": dict(self.filter_reasons),
            "rules_triggered": len(self.rule_counts),
            "top_rules": sorted(
                self.rule_counts.items(),
                key=lambda x: x[1],
                reverse=True
            )[:10]
        }

    def get_high_severity_findings(self) -> List[Finding]:
        """
        获取所有高危发现

        返回:
            高危发现列表
        """
        return [f for f in self.findings if f.rule.severity.level == "HIGH"]

    def calculate_accuracy_metrics(
            self,
            expected_findings: List['Finding'],
            expected_non_findings: List['Location']
    ) -> Dict[str, Any]:
        """
        基于已标注数据计算准确率指标

        这是满足量化目标的核心方法，直接计算:
        - 误报率 (目标 < 5%)
        - 漏报率 (目标 < 3%)
        - 精确率、召回率、F1 分数

        参数:
            expected_findings: 应该被检测到的发现（真阳性标准）
            expected_non_findings: 不应该检测到的位置（真阴性标准）

        返回:
            完整的准确率指标字典
        """
        # 收集检测到的位置（文件路径 + 行号 + 匹配字符串）
        detected_set = {
            (f.location.file_path, f.location.line_number, f.matched_string)
            for f in self.findings
        }

        # 期望检测到的位置
        expected_set = {
            (f.location.file_path, f.location.line_number, f.matched_string)
            for f in expected_findings
        }

        # 期望不检测的位置
        non_finding_set = {
            (l.file_path, l.line_number)
            for l in expected_non_findings
        }

        # ---- 计算四个基础指标 ----
        true_positives = len(detected_set & expected_set)  # TP: 正确检测
        false_positives = len(detected_set - expected_set)  # FP: 误报
        false_negatives = len(expected_set - detected_set)  # FN: 漏报

        # 在非期望位置中正确未检测的数量 (TN)
        detected_non_finding = {
                                   (f.location.file_path, f.location.line_number)
                                   for f in self.findings
                               } & non_finding_set
        true_negatives = len(non_finding_set) - len(detected_non_finding)

        # ---- 计算衍生指标 ----
        total_predictions = true_positives + false_positives
        total_actual = true_positives + false_negatives

        # 精确率 = TP / (TP + FP) - 检测结果中有多少是正确的
        precision = true_positives / total_predictions if total_predictions > 0 else 0.0

        # 召回率 = TP / (TP + FN) - 真实敏感信息有多少被检测到
        recall = true_positives / total_actual if total_actual > 0 else 0.0

        # F1 = 2 * P * R / (P + R) - 精确率和召回率的调和平均
        f1_score = (
            2 * precision * recall / (precision + recall)
            if (precision + recall) > 0 else 0.0
        )

        # 误报率 = FP / (FP + TN) - 所有非敏感位置中被误报的比例
        false_positive_rate = (
            false_positives / (false_positives + true_negatives)
            if (false_positives + true_negatives) > 0 else 0.0
        )

        # 漏报率 = FN / (TP + FN) - 所有真实敏感信息中被遗漏的比例
        false_negative_rate = (
            false_negatives / total_actual
            if total_actual > 0 else 0.0
        )

        return {
            # 基础计数
            "true_positives": true_positives,
            "false_positives": false_positives,
            "true_negatives": true_negatives,
            "false_negatives": false_negatives,
            # 核心指标 (百分比形式)
            "precision": round(precision * 100, 2),  # 精确率 %
            "recall": round(recall * 100, 2),  # 召回率 %
            "f1_score": round(f1_score * 100, 2),  # F1 分数 %
            "false_positive_rate": round(false_positive_rate * 100, 2),  # 误报率 %
            "false_negative_rate": round(false_negative_rate * 100, 2),  # 漏报率 %
            # 是否达标
            "fp_rate_pass": false_positive_rate < 0.05,  # 误报率 < 5%
            "fn_rate_pass": false_negative_rate < 0.03,  # 漏报率 < 3%
            "coverage_pass": recall >= 0.90,  # 覆盖率 >= 90%
        }

    def to_dict(self) -> Dict[str, Any]:
        """转换为完整的可序列化字典"""
        return {
            "summary": self.get_summary(),
            "findings": [f.to_dict() for f in self.findings],
            "rule_set": self.rule_set.to_dict()
        }


@dataclass
class ScanConfig:
    """
    扫描配置

    控制扫描行为的全局配置参数。
    支持从 YAML/JSON 配置文件加载，也支持编程式设置。

    属性:
        target_paths: 扫描目标路径
        exclude_patterns: 排除的文件模式
        enabled_rule_sets: 启用的规则集
        custom_rule_paths: 自定义规则文件路径
        output_formats: 输出格式列表
        include_fix_suggestions: 是否包含修复建议
        timeout_seconds: 扫描超时
        max_workers: 最大并发数
    """
    # 扫描目标
    target_paths: List[str] = field(default_factory=lambda: ["."])

    # 排除规则
    exclude_patterns: List[str] = field(default_factory=lambda: [
        "*test*", "*_test.py", "test_*.py",
        "venv/*", ".venv/*", "__pycache__/*",
        "*.egg-info/*", "build/*", "dist/*",
    ])

    # 规则配置
    enabled_rule_sets: List[str] = field(default_factory=list)
    disabled_rule_ids: List[str] = field(default_factory=list)
    custom_rule_paths: List[str] = field(default_factory=list)

    # 输出配置
    output_formats: List[str] = field(default_factory=lambda: ["json"])
    output_path: str = "./bandit_reports"
    include_fix_suggestions: bool = True
    verbose: bool = False

    # 性能配置
    timeout_seconds: int = 300
    max_workers: int = 0  # 0 = 自动检测
    cache_enabled: bool = True

    # 质量门禁
    max_false_positive_rate: float = 0.05  # 5%
    max_false_negative_rate: float = 0.03  # 3%
    min_recall: float = 0.90  # 90%

    def __post_init__(self):
        """验证配置的有效性"""
        if self.timeout_seconds < 0:
            raise ValueError("超时时间不能为负数")
        if not (0.0 <= self.max_false_positive_rate <= 1.0):
            raise ValueError("误报率阈值必须在 0.0-1.0 之间")

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "target_paths": self.target_paths,
            "exclude_patterns": self.exclude_patterns,
            "enabled_rule_sets": self.enabled_rule_sets,
            "disabled_rule_ids": self.disabled_rule_ids,
            "custom_rule_paths": self.custom_rule_paths,
            "output_formats": self.output_formats,
            "output_path": self.output_path,
            "include_fix_suggestions": self.include_fix_suggestions,
            "timeout_seconds": self.timeout_seconds,
            "max_workers": self.max_workers,
            "quality_gates": {
                "max_false_positive_rate": self.max_false_positive_rate,
                "max_false_negative_rate": self.max_false_negative_rate,
                "min_recall": self.min_recall,
            }
        }