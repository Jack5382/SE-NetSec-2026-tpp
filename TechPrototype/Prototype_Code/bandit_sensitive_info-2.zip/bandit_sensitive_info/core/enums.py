"""
枚举类型定义
============

提供项目中所有标准化的枚举值，保证数据一致性。
所有枚举都使用 str 作为基类，便于 JSON 序列化和比较。
"""

from enum import Enum


class SeverityLevel(str, Enum):
    """
    严重程度等级枚举

    对应 CVSS 评分体系的三级严重度:
    - HIGH:   7.0-10.0 (需要立即修复)
    - MEDIUM: 4.0-6.9  (需要计划修复)
    - LOW:    0.1-3.9  (建议修复)
    """
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"

    def to_cvss_range(self) -> tuple:
        """获取对应的 CVSS 评分范围"""
        _ranges = {
            self.HIGH: (7.0, 10.0),
            self.MEDIUM: (4.0, 6.9),
            self.LOW: (0.1, 3.9),
        }
        return _ranges[self]

    def get_default_cvss(self) -> float:
        """获取默认 CVSS 评分"""
        _defaults = {self.HIGH: 8.5, self.MEDIUM: 5.5, self.LOW: 2.5}
        return _defaults[self]

    def is_critical(self) -> bool:
        """HIGH 级别且有 CVSS >= 9.0 视为严重"""
        return self == self.HIGH


class ConfidenceLevel(str, Enum):
    """
    置信度等级枚举

    表示检测结果的可靠程度:
    - HIGH:   明确匹配，几乎不会是误报
    - MEDIUM: 疑似匹配，需要人工确认
    - LOW:    启发式匹配，误报概率较高
    """
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class DetectionMethod(str, Enum):
    """
    检测方法枚举

    记录检测到敏感信息所用的技术手段:
    - PATTERN:  正则表达式模式匹配
    - AST:      抽象语法树分析
    - ENTROPY:  熵值分析
    - HYBRID:   混合方法（多种手段结合）
    - SEMANTIC: 语义分析（基于代码上下文和变量流）
    """
    PATTERN = "PATTERN"
    AST = "AST"
    ENTROPY = "ENTROPY"
    HYBRID = "HYBRID"
    SEMANTIC = "SEMANTIC"

    def is_high_confidence_method(self) -> bool:
        """判断是否为高置信度检测方法"""
        return self in (self.PATTERN, self.SEMANTIC, self.HYBRID)


class SensitiveCategory(str, Enum):
    """
    敏感信息分类枚举

    完整覆盖项目要求的 90%+ 常见硬编码敏感信息类型:
    - 密码类: PASSWORD
    - API 密钥类: API_KEY, CLOUD_CREDENTIAL
    - 令牌类: JWT_TOKEN, OAUTH_TOKEN
    - 连接串类: DATABASE_URL
    - 密钥类: PRIVATE_KEY, SECRET_KEY
    - 证书类: CERTIFICATE
    - 其他: OTHER
    """
    PASSWORD = "password"  # 密码
    API_KEY = "api_key"  # API 密钥
    JWT_TOKEN = "jwt_token"  # JWT 令牌
    DATABASE_URL = "database_url"  # 数据库连接串
    PRIVATE_KEY = "private_key"  # 私钥 (SSH/PGP)
    OAUTH_TOKEN = "oauth_token"  # OAuth 令牌
    CLOUD_CREDENTIAL = "cloud_credential"  # 云服务凭证
    CERTIFICATE = "certificate"  # 证书
    SECRET_KEY = "secret_key"  # 加密密钥
    OTHER = "other"  # 其他

    def get_cwe_id(self) -> str:
        """获取对应的 CWE 编号"""
        _cwe_map = {
            self.PASSWORD: "CWE-798",  # 硬编码凭证
            self.API_KEY: "CWE-798",
            self.JWT_TOKEN: "CWE-798",
            self.DATABASE_URL: "CWE-798",
            self.PRIVATE_KEY: "CWE-321",  # 使用硬编码加密密钥
            self.OAUTH_TOKEN: "CWE-798",
            self.CLOUD_CREDENTIAL: "CWE-798",
            self.CERTIFICATE: "CWE-295",  # 不当的证书验证
            self.SECRET_KEY: "CWE-321",
        }
        return _cwe_map.get(self, "CWE-798")

    def get_owasp_category(self) -> str:
        """获取对应的 OWASP Top 10 (2021) 分类"""
        return "A07:2021 - 身份识别和认证失败"

    def get_priority(self) -> int:
        """获取修复优先级 (1=最高)"""
        _priority = {
            self.PASSWORD: 1,
            self.API_KEY: 1,
            self.CLOUD_CREDENTIAL: 1,
            self.SECRET_KEY: 1,
            self.PRIVATE_KEY: 2,
            self.JWT_TOKEN: 2,
            self.OAUTH_TOKEN: 2,
            self.DATABASE_URL: 3,
            self.CERTIFICATE: 3,
        }
        return _priority.get(self, 4)


class FilterType(str, Enum):
    """
    过滤器类型枚举

    定义误报过滤的各个层级（按执行顺序排列）:
    1. COMMENT:        注释过滤（最快）
    2. NOSEC:          #nosec 标记过滤（最快）
    3. TEST_CODE:      测试代码过滤（文件级，很快）
    4. CONSTANT:       常量/默认值过滤（需要上下文）
    5. WHITELIST:      用户白名单过滤
    6. ENTROPY:        熵值阈值过滤
    7. CONTEXT:        上下文语义分析（最慢但最准）
    """
    COMMENT = "comment"
    NOSEC = "nosec"
    TEST_CODE = "test_code"
    CONSTANT = "constant"
    WHITELIST = "whitelist"
    ENTROPY = "entropy_threshold"
    CONTEXT = "context_analysis"

    def get_execution_order(self) -> int:
        """获取执行顺序（数字越小越先执行）"""
        _order = {
            self.COMMENT: 1,
            self.NOSEC: 2,
            self.TEST_CODE: 3,
            self.CONSTANT: 4,
            self.WHITELIST: 5,
            self.ENTROPY: 6,
            self.CONTEXT: 7,
        }
        return _order[self]


class ReportFormat(str, Enum):
    """
    报告输出格式枚举

    支持 Bandit 原生全格式 + 业界标准格式:
    - JSON/CSV/TXT/HTML/XML: Bandit 原生格式
    - SARIF: 静态分析结果交换格式（GitHub 等平台通用）
    - MARKDOWN: 便于集成到文档
    """
    JSON = "json"
    CSV = "csv"
    HTML = "html"
    TXT = "txt"
    XML = "xml"
    SARIF = "sarif"
    MARKDOWN = "markdown"