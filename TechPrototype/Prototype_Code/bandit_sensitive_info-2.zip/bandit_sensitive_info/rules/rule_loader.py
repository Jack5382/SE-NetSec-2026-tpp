"""
规则加载器
=========

从 YAML 文件加载检测规则，支持内置规则和用户自定义规则。

加载流程:
1. 定位规则文件（内置 + 自定义）
2. 解析 YAML 格式的规则定义
3. 验证规则格式完整性
4. 编译正则表达式模式
5. 构建 RuleSet 和 DetectionRule 对象
"""

import os
import logging
from pathlib import Path
from typing import List, Optional, Dict, Any

import yaml

from ..core.models import DetectionRule, RuleSet, Severity

logger = logging.getLogger(__name__)


class RuleLoader:
    """
    规则加载器

    负责从 YAML 文件中加载检测规则，并转换为内部数据结构。

    支持的 YAML 规则格式:
    ```yaml
    name: api_keys
    description: API密钥检测规则集
    enabled_by_default: true
    rules:
      - rule_id: AWS_ACCESS_KEY
        description: 检测硬编码的AWS访问密钥
        category: api_key
        severity:
          level: HIGH
          cvss_score: 8.5
          confidence: HIGH
        pattern: "AKIA[0-9A-Z]{16}"
        exclude_keywords:
          - example
          - testkey
          - youraccesskey
        exclude_patterns:
          - "EXAMPLE.*KEY"
        entropy_analysis_enabled: false
        entropy_threshold: 4.5
        fix_suggestion: 使用 AWS IAM 角色或环境变量存储密钥
        fix_example: 'aws_key = os.environ.get("AWS_ACCESS_KEY_ID")'
        cwe_id: CWE-798
        owasp_category: "A07:2021"
"""


    #内置规则文件目录（相对于当前文件）
    BUILTIN_RULES_DIR = Path(__file__).parent / "builtin"

    #有效的规则分类
    VALID_CATEGORIES = {
        "password", "api_key", "jwt_token", "database_url",
        "private_key", "oauth_token", "cloud_credential",
        "certificate", "secret_key", "other"
    }

    def __init__(self):
        """初始化规则加载器"""
        self.validator = None
        self._loaded_rule_ids = set()


    """
    加载所有规则集

    加载顺序: 内置规则 → 自定义规则

    参数:
    custom_paths: 自定义规则文件路径列表
    include_builtin: 是否加载内置规则

    返回:
    RuleSet 列表

    抛出:
    FileNotFoundError: 规则文件不存在
    ValueError: 规则格式错误
    """

    def load(self,custom_paths: Optional[List[str]] = None,include_builtin: bool = True) -> List[RuleSet]:
        rule_sets = []
        self._loaded_rule_ids.clear()

        #---- 加载内置规则 - ---
        if include_builtin:
            builtin_sets = self._load_builtin_rules()
            rule_sets.extend(builtin_sets)
            logger.info(f"加载了 {len(builtin_sets)} 个内置规则集")

        #---- 加载自定义规则 - ---
        if custom_paths:
            for custom_path in custom_paths:
                try:
                    custom_sets = self._load_from_file(custom_path)
                    rule_sets.extend(custom_sets)
                    logger.info(f"加载自定义规则: {custom_path}")
                except FileNotFoundError:
                    logger.warning(f"自定义规则文件不存在: {custom_path}")
                    raise
                except Exception as e:
                    logger.error(f"加载自定义规则失败: {custom_path} - {e}")
                    raise ValueError(f"规则文件 '{custom_path}' 加载失败: {e}")

        #编译所有规则的正则表达式 ----
        for rule_set in rule_sets:
            for rule in rule_set.rules:
                try:
                    rule.compile_patterns()
                except ValueError as e:
                    logger.error(f"规则 '{rule.rule_id}' 编译失败: {e}")
                    raise

        logger.info(f"规则加载完成，共 {len(rule_sets)} 个规则集，"
            f"{sum(len(rs.rules) for rs in rule_sets)} 条规则")

        return rule_sets


    def _load_builtin_rules(self) -> List[RuleSet]:
        """
        加载内置规则

        从 builtin/ 目录加载所有 .yaml 和 .yml 文件。

        返回:
        RuleSet 列表
        """


        rule_sets = []

        if not self.BUILTIN_RULES_DIR.exists():
            logger.warning(f"内置规则目录不存在: {self.BUILTIN_RULES_DIR}")
            return rule_sets

        #扫描所有YAML文件
        yaml_files = sorted(self.BUILTIN_RULES_DIR.glob("*.yaml"))
        yaml_files += sorted(self.BUILTIN_RULES_DIR.glob("*.yml"))

        for yaml_file in yaml_files:
            try:
                sets = self._load_from_file(str(yaml_file))
                rule_sets.extend(sets)
                logger.debug(f"加载内置规则文件: {yaml_file.name}")
            except Exception as e:
                logger.error(f"内置规则文件 '{yaml_file}' 加载失败: {e}")
                #内置规则加载失败不应中断
                continue

        return rule_sets


    def _load_from_file(self, file_path: str) -> List[RuleSet]:
        """
        从单个 YAML 文件加载规则集

        参数:
        file_path: YAML 文件路径

        返回:
        RuleSet 列表（一个文件可能包含多个规则集）
        """


        #读取文件
        with open(file_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)

        if not data:
            return []

        #支持两种格式：
        #1.顶层是规则集列表
        #2.顶层是单个规则集
        if isinstance(data, list):
            raw_sets = data
        elif isinstance(data, dict):
            raw_sets = [data]
        else:
            raise ValueError(f"无效的规则文件格式: {file_path}")

        rule_sets = []
        for raw_set in raw_sets:
            rule_set = self._parse_rule_set(raw_set, file_path)
            rule_sets.append(rule_set)

        return rule_sets


    def _parse_rule_set(self, raw: Dict[str, Any], source_file: str) -> RuleSet:
        """
        解析单个规则集

        参数:
        raw: 原始 YAML 字典
        source_file: 来源文件路径

        返回:
        RuleSet 对象
        """


        rules = []

        for raw_rule in raw.get("rules", []):
            try:
                rule = self._parse_rule(raw_rule, source_file)
                rules.append(rule)
            except ValueError as e:
                logger.error(
                    f"规则 '{raw_rule.get('rule_id', 'unknown')}' "
                    f"在文件 '{source_file}' 中解析失败: {e}"
                )
                raise

        return RuleSet(
            name=raw.get("name", ""),
            description=raw.get("description", ""),
            enabled_by_default=raw.get("enabled_by_default", True),
            rules=rules
        )


    def _parse_rule(self, raw: Dict[str, Any], source_file: str) -> DetectionRule:
        """
        解析单条规则

        参数:
        raw: 原始规则字典
        source_file: 来源文件路径

        返回:
        DetectionRule 对象

        抛出:
        ValueError: 缺少必填字段或字段值无效
        """


        #---- 验证必填字段 - ---
        rule_id = raw.get("rule_id")
        if not rule_id:
            raise ValueError("缺少必填字段 'rule_id'")

        #检查规则ID唯一性
        if rule_id in self._loaded_rule_ids:
            logger.warning(f"规则 ID '{rule_id}' 重复（来自 {source_file}），将覆盖之前的规则")
        self._loaded_rule_ids.add(rule_id)

        #---- 解析严重程度 - ---
        severity_raw = raw.get("severity", {})
        severity = Severity(
            level=severity_raw.get("level", "MEDIUM").upper(),
            cvss_score=float(severity_raw.get("cvss_score", 0.0)),
            confidence=severity_raw.get("confidence", "MEDIUM").upper()
        )

        #---- 验证分类 - ---
        category = raw.get("category", "other").lower()
        if category not in self.VALID_CATEGORIES:
            logger.warning(
                f"规则 '{rule_id}': 未知分类 '{category}'，使用 'other'"
            )
        category = "other"

        #---- 构建规则对象 - ---
        rule = DetectionRule(
            rule_id=rule_id,
            description=raw.get("description", ""),
            category=category,
            severity=severity,
            pattern=raw.get("pattern"),
            exclude_keywords=raw.get("exclude_keywords", []),
            exclude_patterns=raw.get("exclude_patterns", []),
            entropy_analysis_enabled=raw.get("entropy_analysis_enabled", False),
            entropy_threshold=float(raw.get("entropy_threshold", 4.5)),
            fix_suggestion=raw.get("fix_suggestion", ""),
            fix_example=raw.get("fix_example", ""),
            cwe_id=raw.get("cwe_id", ""),
            owasp_category=raw.get("owasp_category", ""),
        )

        return rule


    def load_single_rule(self, rule_yaml: str) -> DetectionRule:
        """
        从 YAML 字符串加载单条规则

        用于动态配置场景。

        参数:
        rule_yaml: YAML 格式的规则定义字符串

        返回:
        DetectionRule 对象
        """


        raw = yaml.safe_load(rule_yaml)
        rule = self._parse_rule(raw, "<inline>")
        rule.compile_patterns()
        return rule