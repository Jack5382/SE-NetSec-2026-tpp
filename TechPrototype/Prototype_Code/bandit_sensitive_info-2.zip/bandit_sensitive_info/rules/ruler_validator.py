"""
规则校验器
=========

验证检测规则的有效性和完整性。
在规则加载时自动执行，确保所有规则符合规范。

校验项:
- 必填字段检查
- 字段类型检查
- 正则表达式语法检查
- 严重程度值检查
- 规则ID唯一性检查
"""

import re
import logging
from typing import List, Dict, Any, Tuple

from ..core.models import DetectionRule, RuleSet

logger = logging.getLogger(__name__)


class RuleValidator:
    """
    规则校验器

    提供多层次的规则验证，包括:
    - 结构验证：必填字段、类型检查
    - 语法验证：正则表达式有效性
    - 逻辑验证：熵值阈值范围等
    - 冲突检测：规则 ID 唯一性、模式冲突
    """

    # 必填字段
    REQUIRED_FIELDS = ["rule_id"]

    # 推荐字段（缺失时警告但不阻止加载）
    RECOMMENDED_FIELDS = ["description", "pattern", "category"]

    # 有效分类值
    VALID_CATEGORIES = {
        "password", "api_key", "jwt_token", "database_url",
        "private_key", "oauth_token", "cloud_credential",
        "certificate", "secret_key", "other"
    }

    # 有效严重度
    VALID_SEVERITIES = {"HIGH", "MEDIUM", "LOW"}

    def __init__(self):
        """初始化校验器"""
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def validate_rule_set(self, rule_set: RuleSet) -> Tuple[bool, List[str], List[str]]:
        """
        验证整个规则集

        参数:
            rule_set: 待验证的规则集

        返回:
            (是否通过, 错误列表, 警告列表) 的三元组
        """
        self.errors.clear()
        self.warnings.clear()

        # 验证规则集元信息
        self._validate_rule_set_meta(rule_set)

        # 验证每条规则
        seen_ids = set()
        for i, rule in enumerate(rule_set.rules):
            self._validate_rule(rule, i + 1, seen_ids)

        # 检查是否存在模式冲突
        self._check_pattern_conflicts(rule_set.rules)

        is_valid = len(self.errors) == 0
        return is_valid, self.errors.copy(), self.warnings.copy()

    def validate_rule(self, rule: DetectionRule) -> Tuple[bool, List[str], List[str]]:
        """
        验证单条规则

        参数:
            rule: 待验证的规则

        返回:
            (是否通过, 错误列表, 警告列表)
        """
        self.errors.clear()
        self.warnings.clear()

        self._validate_rule(rule, 1, set())

        is_valid = len(self.errors) == 0
        return is_valid, self.errors.copy(), self.warnings.copy()

    def _validate_rule_set_meta(self, rule_set: RuleSet):
        """验证规则集元信息"""
        if not rule_set.name:
            self.warnings.append("规则集名称为空")

        if not rule_set.description:
            self.warnings.append(f"规则集 '{rule_set.name}' 没有描述")

        if not rule_set.rules:
            self.warnings.append(f"规则集 '{rule_set.name}' 不包含任何规则")

    def _validate_rule(self, rule: DetectionRule, index: int, seen_ids: set):
        """
        验证单条规则的所有方面

        参数:
            rule: 规则对象
            index: 规则在列表中的索引
            seen_ids: 已见过的规则ID集合
        """
        prefix = f"规则 #{index} ({rule.rule_id or 'unknown'}):"

        # ---- 必填字段 ----
        if not rule.rule_id:
            self.errors.append(f"{prefix} 缺少 rule_id")
        elif not rule.rule_id.replace("_", "").replace("-", "").isalnum():
            self.errors.append(
                f"{prefix} rule_id '{rule.rule_id}' "
                f"只能包含字母、数字、下划线和连字符"
            )

        # ---- 唯一性检查 ----
        if rule.rule_id and rule.rule_id in seen_ids:
            self.errors.append(f"{prefix} rule_id '{rule.rule_id}' 重复")
        seen_ids.add(rule.rule_id)

        # ---- 推荐字段 ----
        if not rule.description:
            self.warnings.append(f"{prefix} 缺少 description")

        if not rule.pattern and not rule.entropy_analysis_enabled:
            self.warnings.append(
                f"{prefix} 既没有 pattern 也没有启用熵值分析，"
                f"规则将不会检测到任何内容"
            )

        # ---- 分类检查 ----
        if rule.category and rule.category not in self.VALID_CATEGORIES:
            self.warnings.append(
                f"{prefix} 未知分类 '{rule.category}'，"
                f"有效值: {self.VALID_CATEGORIES}"
            )

        # ---- 严重程度检查 ----
        if rule.severity.level not in self.VALID_SEVERITIES:
            self.errors.append(
                f"{prefix} 无效的严重程度 '{rule.severity.level}'"
            )

        if not (0.0 <= rule.severity.cvss_score <= 10.0):
            self.errors.append(
                f"{prefix} CVSS 评分 {rule.severity.cvss_score} 超出范围 0-10"
            )

        # ---- 正则表达式语法检查 ----
        if rule.pattern:
            try:
                re.compile(rule.pattern)
            except re.error as e:
                self.errors.append(
                    f"{prefix} pattern 正则语法错误: {e}"
                )

        for i, exclude_pattern in enumerate(rule.exclude_patterns):
            try:
                re.compile(exclude_pattern)
            except re.error as e:
                self.errors.append(
                    f"{prefix} exclude_patterns[{i}] 正则语法错误: {e}"
                )

        # ---- 熵值检查 ----
        if rule.entropy_analysis_enabled:
            if not (0.0 <= rule.entropy_threshold <= 8.0):
                self.errors.append(
                    f"{prefix} 熵值阈值 {rule.entropy_threshold} "
                    f"超出有效范围 0.0-8.0"
                )

            if rule.entropy_threshold < 3.0:
                self.warnings.append(
                    f"{prefix} 熵值阈值 {rule.entropy_threshold} 过低，"
                    f"可能产生大量误报"
                )

            if rule.entropy_threshold > 7.0:
                self.warnings.append(
                    f"{prefix} 熵值阈值 {rule.entropy_threshold} 过高，"
                    f"可能漏报部分密钥"
                )

    def _check_pattern_conflicts(self, rules: List[DetectionRule]):
        """
        检查规则之间的模式冲突

        检查是否有两个规则的 pattern 可能匹配相同的字符串。

        参数:
            rules: 规则列表
        """
        # 简单实现：检查是否有相同的 pattern 字符串
        patterns = {}
        for rule in rules:
            if rule.pattern:
                if rule.pattern in patterns:
                    self.warnings.append(
                        f"规则 '{rule.rule_id}' 和 '{patterns[rule.pattern]}' "
                        f"使用了相同的检测模式"
                    )
                patterns[rule.pattern] = rule.rule_id

    def generate_report(self) -> str:
        """
        生成验证报告

        返回:
            可读的验证报告文本
        """
        lines = []
        lines.append("=" * 50)
        lines.append("规则验证报告")
        lines.append("=" * 50)

        if self.errors:
            lines.append(f"\n错误 ({len(self.errors)}):")
            for error in self.errors:
                lines.append(f"  ❌ {error}")

        if self.warnings:
            lines.append(f"\n警告 ({len(self.warnings)}):")
            for warning in self.warnings:
                lines.append(f"  ⚠️  {warning}")

        if not self.errors and not self.warnings:
            lines.append("\n✅ 所有规则验证通过")

        lines.append("=" * 50)
        return "\n".join(lines)