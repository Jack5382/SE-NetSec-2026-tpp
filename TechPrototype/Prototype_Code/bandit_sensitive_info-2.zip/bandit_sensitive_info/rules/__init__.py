"""
规则管理模块
===========

管理敏感信息检测规则的加载、验证和缓存。

功能:
- 从 YAML 文件加载内置和自定义规则
- 规则格式验证
- 正则表达式预编译优化
- 规则热加载支持
"""

from .rule_loader import RuleLoader

#from .rule_validator import RuleValidator


def load_rules(rule_paths=None, include_builtin=True):
    """
    便捷的规则加载函数

    参数:
        rule_paths: 自定义规则文件路径列表，默认为None
        include_builtin: 是否加载内置规则，默认为True

    返回:
        包含所有加载规则的 RuleSet 列表

    示例:
        rules = load_rules(custom_rules=["my_rules.yaml"])
    """
    loader = RuleLoader()
    return loader.load(rule_paths, include_builtin)


__all__ = ["RuleLoader",  "load_rules"]