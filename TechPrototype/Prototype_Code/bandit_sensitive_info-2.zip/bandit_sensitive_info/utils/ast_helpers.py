"""
AST 辅助工具
===========

提供 Python AST 语法树的遍历和分析辅助函数。
用于检测器提取代码结构信息。
"""

import ast
from typing import List, Tuple, Optional


def find_assignments(tree: ast.AST, variable_name: str = None) -> List[ast.Assign]:
    """
    查找 AST 树中的所有赋值语句

    参数:
        tree: AST 语法树
        variable_name: 可选，限定查找特定变量名的赋值

    返回:
        匹配的赋值节点列表

    示例:
        >>> tree = ast.parse("x = 1\\ny = 2")
        >>> nodes = find_assignments(tree, "x")
        >>> len(nodes)
        1
    """
    assignments = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            if variable_name is None:
                assignments.append(node)
            else:
                for target in node.targets:
                    if _get_name(target) == variable_name:
                        assignments.append(node)
                        break

    return assignments


def find_string_literals(tree: ast.AST) -> List[Tuple[str, int, int]]:
    """
    查找 AST 树中的所有字符串字面量

    参数:
        tree: AST 语法树

    返回:
        (字符串值, 行号, 列偏移) 的列表

    示例:
        >>> tree = ast.parse('x = "hello"')
        >>> find_string_literals(tree)
        [('hello', 1, 4)]
    """
    strings = []

    for node in ast.walk(tree):
        # Python 3.8+ 使用 Constant
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            strings.append((
                node.value,
                getattr(node, 'lineno', 1),
                getattr(node, 'col_offset', 0)
            ))
        # Python 3.7 及以下使用 Str
        elif hasattr(ast, 'Str') and isinstance(node, ast.Str):
            strings.append((
                node.s,
                getattr(node, 'lineno', 1),
                getattr(node, 'col_offset', 0)
            ))

    return strings


def get_all_string_nodes(tree: ast.AST) -> List[ast.AST]:
    """
    获取所有字符串相关的 AST 节点

    兼容 Python 3.7 (ast.Str) 和 3.8+ (ast.Constant)

    参数:
        tree: AST 语法树

    返回:
        字符串节点列表
    """
    nodes = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, (str, bytes)):
            nodes.append(node)
        elif hasattr(ast, 'Str') and isinstance(node, ast.Str):
            nodes.append(node)
        elif hasattr(ast, 'Bytes') and isinstance(node, ast.Bytes):
            nodes.append(node)

    return nodes


def extract_variable_name(node: ast.AST) -> Optional[str]:
    """
    从 AST 节点提取变量名

    支持:
    - ast.Name: 简单变量
    - ast.Attribute: 属性访问
    - ast.Subscript: 下标访问

    参数:
        node: AST 节点

    返回:
        变量名字符串或 None
    """
    if isinstance(node, ast.Name):
        return node.id
    elif isinstance(node, ast.Attribute):
        return node.attr
    elif isinstance(node, ast.Subscript):
        if isinstance(node.value, ast.Name):
            return node.value.id
    return None


def _get_name(node: ast.AST) -> Optional[str]:
    """内部辅助: 获取节点的名称"""
    return extract_variable_name(node)


def is_constant_value(node: ast.AST) -> bool:
    """
    判断节点是否为常量值

    参数:
        node: AST 节点

    返回:
        True 如果是常量
    """
    if isinstance(node, ast.Constant):
        return True
    if hasattr(ast, 'Str') and isinstance(node, ast.Str):
        return True
    if hasattr(ast, 'Num') and isinstance(node, ast.Num):
        return True
    return False


def get_constant_value(node: ast.AST) -> Optional[str]:
    """
    获取常量节点的值

    参数:
        node: AST 常量节点

    返回:
        常量值的字符串表示
    """
    if isinstance(node, ast.Constant):
        value = node.value
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return value.decode('utf-8', errors='ignore')
    elif hasattr(ast, 'Str') and isinstance(node, ast.Str):
        return node.s
    return None