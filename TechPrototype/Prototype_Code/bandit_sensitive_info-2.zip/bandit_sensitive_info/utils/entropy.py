"""
熵值计算工具
===========

提供香农熵计算及相关判断函数，
用于识别高随机性字符串（密钥、令牌、Base64编码数据等）。

熵值参考范围:
- 0.0-3.0: 低随机性（纯英文、重复模式）
- 3.0-4.5: 中低随机性（代码、配置文件）
- 4.5-5.5: 中高随机性（混合字符、短密钥）
- 5.5-8.0: 高随机性（加密密钥、随机令牌、高质量Base64）
"""

import math
from collections import Counter
from typing import Dict, Tuple


def calculate_shannon_entropy(data: str) -> float:
    """
    计算字符串的香农熵（Shannon Entropy）

    使用公式: H = -Σ p(x) * log2(p(x))
    其中 p(x) 是字符 x 在数据中出现的概率。

    参数:
        data: 输入字符串

    返回:
        熵值 (0.0-8.0)，值越高随机性越强

    示例:
        >>> calculate_shannon_entropy("aaa")
        0.0
        >>> calculate_shannon_entropy("abc123")
        2.58
        >>> calculate_shannon_entropy("Kx9mP2$vL5@nQ8#")
        3.75
    """
    if not data:
        return 0.0

    length = len(data)

    # 统计字符频率
    char_counts = Counter(data)

    # 计算熵值
    entropy = 0.0
    for count in char_counts.values():
        probability = count / length
        entropy -= probability * math.log2(probability)

    return entropy


def calculate_relative_entropy(data: str) -> float:
    """
    计算相对熵值（归一化到 0.0-1.0）

    相对熵 = 香农熵 / log2(不同字符数)
    1.0 表示在给定字符集内完全随机。

    参数:
        data: 输入字符串

    返回:
        相对熵值 (0.0-1.0)

    示例:
        >>> calculate_relative_entropy("abcabcabc")
        0.0
        >>> calculate_relative_entropy("Kx9mP2vL5nQ8")
        1.0
    """
    if not data:
        return 0.0

    shannon = calculate_shannon_entropy(data)
    unique_chars = len(set(data))

    if unique_chars <= 1:
        return 0.0

    max_entropy = math.log2(unique_chars)
    if max_entropy == 0:
        return 0.0

    return min(shannon / max_entropy, 1.0)


def is_high_entropy_string(data: str, threshold: float = 4.5) -> bool:
    """
    判断字符串是否为高熵（高随机性）字符串

    常用于判断 Base64 编码数据、加密密钥等。

    参数:
        data: 输入字符串
        threshold: 熵值阈值，默认 4.5

    返回:
        True 如果熵值高于阈值

    示例:
        >>> is_high_entropy_string("Hello World")
        False
        >>> is_high_entropy_string("dGhpcyBpcyBhIGtleQ==")
        True
    """
    return calculate_shannon_entropy(data) >= threshold


def get_entropy_profile(data: str) -> Dict[str, float]:
    """
    获取字符串的完整熵值分析结果

    返回包括:
    - shannon_entropy: 香农熵值
    - relative_entropy: 相对熵值
    - length: 字符串长度
    - unique_chars: 唯一字符数
    - likelihood: 是密钥/令牌的可能性 (0-100)

    参数:
        data: 输入字符串

    返回:
        熵值指标字典
    """
    if not data:
        return {
            "shannon_entropy": 0.0,
            "relative_entropy": 0.0,
            "length": 0,
            "unique_chars": 0,
            "likelihood": 0.0,
        }

    shannon = calculate_shannon_entropy(data)
    relative = calculate_relative_entropy(data)
    unique = len(set(data))
    length = len(data)

    # 计算密钥可能性
    # 综合考虑熵值、长度、字符多样性
    likelihood = 0.0

    # 熵值贡献 (0-50分)
    if shannon >= 5.5:
        likelihood += 50
    elif shannon >= 4.5:
        likelihood += 35
    elif shannon >= 3.5:
        likelihood += 20

    # 长度贡献 (0-30分)
    if length >= 32:
        likelihood += 30
    elif length >= 20:
        likelihood += 20
    elif length >= 12:
        likelihood += 10

    # 字符多样性贡献 (0-20分)
    if unique >= 20:
        likelihood += 20
    elif unique >= 10:
        likelihood += 10

    return {
        "shannon_entropy": round(shannon, 4),
        "relative_entropy": round(relative, 4),
        "length": length,
        "unique_chars": unique,
        "likelihood": min(100.0, likelihood),
    }