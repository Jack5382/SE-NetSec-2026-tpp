"""
工具模块
=======

提供熵值计算、AST辅助等底层工具函数。
"""

from .entropy import (
    calculate_shannon_entropy,
    calculate_relative_entropy,
    is_high_entropy_string,
    get_entropy_profile,
)
from .ast_helpers import (
    find_assignments,
    find_string_literals,
    get_all_string_nodes,
    extract_variable_name,
)

__all__ = [
    "calculate_shannon_entropy",
    "calculate_relative_entropy",
    "is_high_entropy_string",
    "get_entropy_profile",
    "find_assignments",
    "find_string_literals",
    "get_all_string_nodes",
    "extract_variable_name",
]