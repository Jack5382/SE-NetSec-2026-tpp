"""
修复建议生成器
=============

根据检测到的敏感信息类型和上下文，
自动生成具体的修复建议和代码示例。

支持的修复建议类型:
- 环境变量迁移
- 密钥管理服务集成
- IAM 角色使用
- 安全编码实践
"""

import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)


class FixSuggester:
    """
    修复建议生成器

    为检测到的每类敏感信息提供精准的修复方案。
    建议包含:
    - 问题说明
    - 修复步骤
    - 修复代码示例
    - 相关安全标准引用
    """

    # 按类别组织的修复建议模板
    _SUGGESTIONS: Dict[str, Dict[str, Any]] = {
        "password": {
            "title": "硬编码密码漏洞",
            "description": "代码中包含硬编码的密码，攻击者可通过查看源码或逆向工程获取密码。",
            "fix_steps": [
                "立即更换已泄露的密码",
                "将密码移至环境变量或密钥管理服务（如 HashiCorp Vault, AWS Secrets Manager）",
                "更新代码从安全来源读取密码",
                "确保含密码的代码历史记录已被清理（使用 git-filter-repo 等工具）"
            ],
            "code_example": (
                '# 修复前（危险）:\n'
                'password = "MySecretPass123"\n\n'
                '# 修复后（安全）:\n'
                'import os\n'
                'password = os.environ.get("DB_PASSWORD")\n'
                'if not password:\n'
                '    raise ValueError("请设置 DB_PASSWORD 环境变量")'
            ),
            "references": [
                "CWE-798: Use of Hard-coded Credentials",
                "OWASP A07:2021: Identification and Authentication Failures"
            ]
        },
        "api_key": {
            "title": "硬编码API密钥漏洞",
            "description": "代码中直接包含API密钥，一旦泄露可能被用于未授权访问云资源或服务。",
            "fix_steps": [
                "立即在服务提供商处吊销此密钥并生成新密钥",
                "使用环境变量或 IAM 角色（AWS/GCP/Azure）进行认证",
                "在本地开发中使用 AWS CLI profiles 或 gcloud auth",
                "检查 Git 历史，确保密钥未被提交"
            ],
            "code_example": (
                '# 修复前（危险）:\n'
                'AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"\n\n'
                '# 修复后 - 方式1: 使用环境变量\n'
                'import os\n'
                'import boto3\n'
                'client = boto3.client(\n'
                '    "s3",\n'
                '    aws_access_key_id=os.environ.get("AWS_ACCESS_KEY_ID"),\n'
                '    aws_secret_access_key=os.environ.get("AWS_SECRET_ACCESS_KEY")\n'
                ')\n\n'
                '# 修复后 - 方式2: 使用 IAM 角色（推荐）\n'
                'client = boto3.client("s3")  # 自动使用 IAM 角色凭证'
            ),
            "references": [
                "CWE-798: Use of Hard-coded Credentials",
                "AWS IAM Best Practices"
            ]
        },
        "jwt_token": {
            "title": "硬编码JWT令牌/密钥漏洞",
            "description": "JWT令牌或签名密钥硬编码在代码中，攻击者可伪造令牌或以任意用户身份访问系统。",
            "fix_steps": [
                "立即更换 JWT 签名密钥",
                "将 JWT 密钥移至环境变量或密钥管理服务",
                "确保 JWT 有过期时间且不过长",
                "使用非对称加密算法（RS256/ES256）替代对称算法"
            ],
            "code_example": (
                '# 修复前（危险）:\n'
                'JWT_SECRET = "my-super-secret-key"\n'
                'token = jwt.encode(payload, JWT_SECRET)\n\n'
                '# 修复后（安全）:\n'
                'import os\n'
                'import jwt\n'
                'JWT_SECRET = os.environ["JWT_SECRET_KEY"]\n\n'
                '# 推荐: 使用 RSA 非对称加密\n'
                'with open(os.environ["JWT_PRIVATE_KEY_PATH"]) as f:\n'
                '    private_key = f.read()\n'
                'token = jwt.encode(payload, private_key, algorithm="RS256")'
            ),
            "references": [
                "CWE-798: Use of Hard-coded Credentials",
                "JWT Best Practices: https://auth0.com/blog/critical-vulnerabilities-in-json-web-token-libraries/"
            ]
        },
        "database_url": {
            "title": "硬编码数据库连接串漏洞",
            "description": "数据库连接字符串包含完整凭证，攻击者可获取数据库完全访问权限。",
            "fix_steps": [
                "立即更改数据库密码",
                "使用环境变量或应用配置服务存储连接信息",
                "考虑使用数据库代理或连接池",
                "使用 SSL/TLS 加密数据库连接"
            ],
            "code_example": (
                '# 修复前（危险）:\n'
                'DATABASE_URL = "mysql://user:password@localhost/db"\n\n'
                '# 修复后（安全）:\n'
                'import os\n'
                'DATABASE_URL = os.environ.get(\n'
                '    "DATABASE_URL",\n'
                '    "sqlite:///dev.db"  # 仅开发环境默认值\n'
                ')'
            ),
            "references": [
                "CWE-798: Use of Hard-coded Credentials"
            ]
        },
        "private_key": {
            "title": "硬编码私钥漏洞",
            "description": "加密私钥直接出现在代码中，这是极其严重的安全事件。私钥应永不离开安全存储设施。",
            "fix_steps": [
                "立即更换所有相关密钥和证书",
                "将此事件报告为安全事故",
                "使用硬件安全模块 (HSM) 或密钥管理服务",
                "通过环境变量引用密钥文件路径，而非直接包含密钥内容"
            ],
            "code_example": (
                '# 修复前（极度危险）:\n'
                'PRIVATE_KEY = """-----BEGIN RSA PRIVATE KEY-----\n'
                'MIIEpAIBAAKCAQEA...\n'
                '-----END RSA PRIVATE KEY-----"""\n\n'
                '# 修复后（安全）:\n'
                'import os\n'
                'with open(os.environ["PRIVATE_KEY_PATH"]) as f:\n'
                '    private_key = f.read()'
            ),
            "references": [
                "CWE-321: Use of Hard-coded Cryptographic Key",
                "NIST SP 800-57: Key Management Guidelines"
            ]
        },
        "secret_key": {
            "title": "硬编码加密密钥漏洞",
            "description": "加密/解密的密钥硬编码在代码中，攻击者可解密所有受保护数据。",
            "fix_steps": [
                "立即更换加密密钥并重新加密所有数据",
                "使用密钥管理服务 (KMS) 管理加密密钥",
                "实施密钥轮换策略",
                "使用信封加密模式"
            ],
            "code_example": (
                '# 修复前（危险）:\n'
                'ENCRYPTION_KEY = "my-32-byte-encryption-key!!!"\n\n'
                '# 修复后（安全）:\n'
                'import os\n'
                'from cryptography.fernet import Fernet\n\n'
                'ENCRYPTION_KEY = os.environ["ENCRYPTION_KEY"].encode()\n'
                'cipher = Fernet(ENCRYPTION_KEY)'
            ),
            "references": [
                "CWE-321: Use of Hard-coded Cryptographic Key",
                "AWS KMS / GCP KMS / Azure Key Vault"
            ]
        },
        "oauth_token": {
            "title": "硬编码OAuth令牌漏洞",
            "description": "OAuth访问令牌硬编码在代码中，攻击者可以此身份访问受保护资源。",
            "fix_steps": [
                "立即吊销此令牌",
                "使用 OAuth 授权码流程动态获取令牌",
                "安全存储 refresh_token"
            ],
            "code_example": (
                '# 修复前（危险）:\n'
                'OAUTH_TOKEN = "ya29.a0AfH6S..."\n\n'
                '# 修复后（安全）:\n'
                'from google.oauth2.credentials import Credentials\n'
                'credentials = Credentials.from_authorized_user_file(\n'
                '    os.environ["TOKEN_PATH"]\n'
                ')'
            ),
            "references": [
                "CWE-798: Use of Hard-coded Credentials",
                "OAuth 2.0 Best Practices"
            ]
        },
    }

    # 默认修复建议（用于未分类的敏感信息）
    _DEFAULT_SUGGESTION: Dict[str, Any] = {
        "title": "硬编码敏感信息漏洞",
        "description": "代码中包含硬编码的敏感信息，存在安全隐患。",
        "fix_steps": [
            "将敏感信息移至环境变量或安全的配置管理服务",
            "检查代码历史，确保敏感信息未被提交到版本控制系统",
            "如已提交，使用工具清理 Git 历史"
        ],
        "code_example": (
            '# 修复前（危险）:\n'
            'SENSITIVE_DATA = "hardcoded_value"\n\n'
            '# 修复后（安全）:\n'
            'import os\n'
            'SENSITIVE_DATA = os.environ.get("SENSITIVE_DATA_CONFIG")'
        ),
        "references": ["CWE-798: Use of Hard-coded Credentials"]
    }

    def get_suggestion(
            self,
            category: str,
            matched_string: str = "",
            variable_name: str = ""
    ) -> str:
        """
        获取针对特定类别的修复建议

        参数:
            category: 敏感信息类别
            matched_string: 匹配到的原始字符串（脱敏后）
            variable_name: 关联的变量名

        返回:
            格式化的修复建议文本
        """
        suggestion = self._SUGGESTIONS.get(
            category.lower(),
            self._DEFAULT_SUGGESTION
        )

        lines = []
        lines.append(f"\n{'=' * 60}")
        lines.append(f"🔴 {suggestion['title']}")
        lines.append(f"{'=' * 60}")

        # 问题说明
        lines.append(f"\n📋 问题说明:")
        lines.append(f"   {suggestion['description']}")

        # 检测到的信息
        if variable_name:
            lines.append(f"\n📍 变量名: {variable_name}")
        if matched_string:
            lines.append(f"📍 检测值: {matched_string}")

        # 修复步骤
        lines.append(f"\n🔧 修复步骤:")
        for i, step in enumerate(suggestion['fix_steps'], 1):
            lines.append(f"   {i}. {step}")

        # 代码示例
        lines.append(f"\n💻 修复代码示例:")
        for line in suggestion['code_example'].split('\n'):
            lines.append(f"   {line}")

        # 参考信息
        lines.append(f"\n📚 参考:")
        for ref in suggestion['references']:
            lines.append(f"   - {ref}")

        lines.append(f"{'=' * 60}\n")

        return '\n'.join(lines)

    def get_conciise_suggestion(self, category: str) -> str:
        """
        获取简洁版修复建议（适合内联显示）

        参数:
            category: 敏感信息类别

        返回:
            简洁的修复建议
        """
        suggestion = self._SUGGESTIONS.get(
            category.lower(),
            self._DEFAULT_SUGGESTION
        )

        return (
            f"{suggestion['title']}. "
            f"建议: {suggestion['fix_steps'][0] if suggestion['fix_steps'] else '将敏感信息迁移到安全存储'}"
        )

    def get_fix_example_code(self, category: str) -> str:
        """
        仅获取修复代码示例

        参数:
            category: 敏感信息类别

        返回:
            修复代码字符串
        """
        suggestion = self._SUGGESTIONS.get(
            category.lower(),
            self._DEFAULT_SUGGESTION
        )
        return suggestion['code_example']

    def list_supported_categories(self) -> list:
        """
        列出所有支持的建议类别

        返回:
            类别列表
        """
        return list(self._SUGGESTIONS.keys())