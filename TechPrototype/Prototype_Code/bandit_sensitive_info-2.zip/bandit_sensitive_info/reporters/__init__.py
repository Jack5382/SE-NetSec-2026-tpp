"""
报告增强模块
===========

在 Bandit 原生报告基础上增强输出。
提供修复建议生成和安全评分等功能。
"""

from .fix_suggester import FixSuggester

__all__ = ["FixSuggester"]