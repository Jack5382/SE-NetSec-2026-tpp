from setuptools import setup, find_packages

setup(
    name="bandit-sensitive-info",
    version="1.0.0",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "bandit>=1.7.0",
        "pyyaml>=6.0",
    ],
    entry_points={
        "bandit.plugins": [
            "B901 = bandit_sensitive_info.plugin:sensitive_info_string",
            "B902 = bandit_sensitive_info.plugin:sensitive_info_funcarg",
        ],
    },
)