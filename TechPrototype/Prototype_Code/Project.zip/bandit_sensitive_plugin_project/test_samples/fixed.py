"""
这是修复后的安全样本
"""
import os
import requests
from dotenv import load_dotenv

# 修复方案 1: 从环境变量读取
load_dotenv()
STRIPE_API_KEY = os.environ.get("STRIPE_API_KEY")

# 修复方案 2: 从配置文件或环境变量读取
DATABASE_CONFIG = {
    "host": os.environ.get("DB_HOST", "localhost"),
    "port": int(os.environ.get("DB_PORT", 5432)),
    "username": os.environ.get("DB_USER"),
    "db_password": os.environ.get("DB_PASSWORD")  # 从环境变量读取
}

# 修复方案 3: 同样使用环境变量
class AppConfig:
    DEBUG = os.environ.get("DEBUG", "False").lower() == "true"
    JWT_SECRET = os.environ.get("JWT_SECRET")

def make_payment():
    amount = 100
    if STRIPE_API_KEY:
        headers = {"Authorization": f"Bearer {STRIPE_API_KEY}"}
        requests.post("https://api.stripe.com/v1/charges", headers=headers)