"""
这是一个包含硬编码敏感信息漏洞的测试样本
"""
import requests

# 漏洞 1: 直接硬编码 API Key (B901)
STRIPE_API_KEY = "sk_live_9e10d91f827a3b5c6d7e8f9a"

# 漏洞 2: 字典中的密码 (B902)
DATABASE_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "username": "admin",
    "db_password": "P@ssw0rd123!Secure"  # 敏感
}

# 漏洞 3: 类属性中的密钥
class AppConfig:
    DEBUG = True
    JWT_SECRET = "my_super_secret_jwt_key_12345"  # 敏感

def make_payment():
    # 安全的代码（不应该报警）
    amount = 100
    # 使用了硬编码的密钥
    headers = {"Authorization": f"Bearer {STRIPE_API_KEY}"}
    requests.post("https://api.stripe.com/v1/charges", headers=headers)

# 安全的代码（不应该报警）
SAFE_CONSTANT = "hello_world"