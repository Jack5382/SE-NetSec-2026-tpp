import sys
import os
import json


def scan_with_bandit(target_path: str, plugin_path: str) -> dict:
    """完全绕过 blacklist，直接注入插件函数"""
    try:
        import bandit
        from bandit.core import config, manager, extension_loader
        import importlib.util

        # 1. 加载插件模块
        spec = importlib.util.spec_from_file_location("sensitive_detector", plugin_path)
        plugin_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(plugin_module)

        # 2. 收集插件函数
        custom_tests = {}
        for name in dir(plugin_module):
            obj = getattr(plugin_module, name)
            if hasattr(obj, '_test_id'):
                custom_tests[obj._test_id] = obj
                print(f"[发现] 自定义规则: {obj._test_id}")

        # 3. 配置 - 关键：不设 tests，让所有内置测试跑不了
        #    然后我们自己只加载自定义的
        b_conf = config.BanditConfig()
        # 设一个不存在的 test_id，让内置测试不运行
        b_conf.tests = None

        # 4. 修复 blacklist 格式（临时把值改成空列表）
        if not hasattr(extension_loader, 'MANAGER'):
            extension_loader.MANAGER = type('obj', (object,), {})()

        saved_blacklist = getattr(extension_loader.MANAGER, 'blacklist', None)
        extension_loader.MANAGER.blacklist = {}  # 空字典，避免遍历时报错

        # 5. 创建 Manager
        b_mgr = manager.BanditManager(
            b_conf,
            agg_type='file',
            debug=False,
            verbose=False,
            quiet=True
        )

        # 6. 恢复 blacklist
        if saved_blacklist is not None:
            extension_loader.MANAGER.blacklist = saved_blacklist

        # 7. 清空内置插件，只加我们的
        if hasattr(b_mgr, 'b_ts') and hasattr(b_mgr.b_ts, 'plugins'):
            b_mgr.b_ts.plugins.clear()
            for tid, tfunc in custom_tests.items():
                b_mgr.b_ts.plugins.append(tfunc)
                print(f"[加载] 已将 {tid} 加入测试集")

        # 8. 扫描
        if os.path.isfile(target_path):
            b_mgr.discover_files([target_path], recursive=False)
        else:
            b_mgr.discover_files([target_path], recursive=True)
        b_mgr.run_tests()

        # 9. 获取结果
        results = b_mgr.get_issue_list()
        issues = []
        for issue_obj in results:
            issues.append({
                "test_id": issue_obj.test_id,
                "severity": issue_obj.severity,
                "confidence": issue_obj.confidence,
                "description": issue_obj.text,
                "file": issue_obj.fname,
                "line": issue_obj.lineno,
                "code_snippet": issue_obj.get_code()
            })

        severity_counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for issue_obj in results:
            sev = issue_obj.severity
            if sev in severity_counts:
                severity_counts[sev] += 1

        total_lines = 0
        for fname in b_mgr.files_list:
            try:
                with open(fname, 'r', encoding='utf-8') as f:
                    total_lines += len(f.readlines())
            except:
                pass

        return {
            "success": True,
            "scan_summary": {
                "total_lines_scanned": total_lines,
                "total_issues_found": len(issues),
                "scan_date": ""
            },
            "severity_counts": severity_counts,
            "issues": issues
        }

    except Exception as e:
        import traceback
        return {
            "error": f"扫描异常: {str(e)}",
            "traceback": traceback.format_exc()
        }


# --------------------------
# 主程序入口
# --------------------------
if __name__ == "__main__":
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PLUGIN_FILE = os.path.join(CURRENT_DIR, "plugin", "sensitive_detector.py")

    # ===== 修改点 1：智能获取目标文件 =====
    if len(sys.argv) >= 2:
        # 命令行模式：python install_plugin.py test_samples/vulnerable.py
        target_path = sys.argv[1]
    else:
        # 双击模式：弹出文件选择对话框
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()  # 隐藏主窗口
        target_path = filedialog.askopenfilename(
            title="选择要扫描的 Python 文件",
            filetypes=[("Python 文件", "*.py"), ("所有文件", "*.*")]
        )
        root.destroy()

        if not target_path:
            print("未选择文件，程序退出。")
            input("按回车键关闭...")
            sys.exit(0)

    if not os.path.exists(target_path):
        print(f"错误: 路径 '{target_path}' 不存在")
        input("按回车键关闭...")
        sys.exit(1)

    print(f"正在使用 Bandit 扫描: {target_path} ...")
    result = scan_with_bandit(target_path, PLUGIN_FILE)

    print("\n" + "=" * 50)
    print("安全扫描结果")
    print("=" * 50)
    print(json.dumps(result, indent=2, ensure_ascii=False))

    # ===== 修改点 2：生成报告并自动打开 =====
    output_file = "security_report.html"  # 改成 HTML 更直观
    with open(output_file, "w", encoding="utf-8") as f:
        # 生成一个简单的 HTML 报告
        f.write("<html><head><meta charset='utf-8'><title>扫描报告</title>")
        f.write("<style>body{font-family:Arial;margin:40px;}")
        f.write(".high{color:red;font-weight:bold}")
        f.write(".issue{background:#fff3f3;padding:10px;margin:10px 0;border-left:4px solid red;}")
        f.write("</style></head><body>")
        f.write(f"<h1>🔍 Bandit 敏感信息扫描报告</h1>")
        f.write(f"<p>扫描文件: {target_path}</p>")

        if result.get("success"):
            summary = result.get("scan_summary", {})
            f.write(f"<p>扫描行数: {summary.get('total_lines_scanned', 0)}</p>")
            f.write(f"<p>发现漏洞: {summary.get('total_issues_found', 0)}</p>")

            for issue in result.get("issues", []):
                f.write(f"<div class='issue'>")
                f.write(f"<p class='high'>⚠ {issue['test_id']} - {issue['severity']}</p>")
                f.write(f"<p>{issue['description']}</p>")
                f.write(f"<p>位置: {issue['file']} 第 {issue['line']} 行</p>")
                f.write(f"<pre>{issue['code_snippet']}</pre>")
                f.write(f"</div>")
        else:
            f.write(f"<p>扫描失败: {result.get('error', '未知错误')}</p>")

        f.write("</body></html>")

    print(f"\n报告已保存至: {os.path.abspath(output_file)}")

    # ===== 修改点 3：自动打开报告 =====
    import webbrowser

    webbrowser.open(os.path.abspath(output_file))

    # ===== 修改点 4：暂停窗口，让用户看到结果 =====
    input("\n按回车键退出...")