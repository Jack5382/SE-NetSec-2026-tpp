"""独立测试插件逻辑"""
import ast
import sys
sys.path.insert(0, r"E:\My item\Software Engineering\bandit_sensitive_plugin_project")

# 模拟一段代码
code = 'STRIPE_API_KEY = "sk_live_9e10d91f827a3b5c6d7e8f9a"'
tree = ast.parse(code)
node = tree.body[0]  # Assign 节点

print("=== AST 结构 ===")
print(f"节点类型: {type(node).__name__}")
print(f"targets: {node.targets}")
print(f"targets[0]类型: {type(node.targets[0]).__name__}")

target = node.targets[0]
if isinstance(target, ast.Name):
    print(f"变量名: {target.id}")

print(f"value类型: {type(node.value).__name__}")
if isinstance(node.value, ast.Constant):
    print(f"value.value: {node.value.value}")
    print(f"value.value类型: {type(node.value.value).__name__}")

# 导入你的检测逻辑
import importlib.util
spec = importlib.util.spec_from_file_location(
    "sensitive_detector",
    r"E:\My item\Software Engineering\bandit_sensitive_plugin_project\plugin\sensitive_detector.py"
)
plugin = importlib.util.module_from_spec(spec)
spec.loader.exec_module(plugin)

print("\n=== 检测逻辑测试 ===")
print(f"_is_sensitive_name('STRIPE_API_KEY'): {plugin._is_sensitive_name('STRIPE_API_KEY')}")
print(f"_is_sensitive_name('api_key'): {plugin._is_sensitive_name('api_key')}")
print(f"_looks_like_a_secret('sk_live_9e10d91f827a3b5c6d7e8f9a'): {plugin._looks_like_a_secret('sk_live_9e10d91f827a3b5c6d7e8f9a')}")

# 手动遍历字典检测
dict_code = '{"db_password": "P@ssw0rd123!Secure"}'
dict_tree = ast.parse(dict_code)
dict_node = dict_tree.body[0].value  # Dict 节点
print(f"\nDict 键类型: {type(dict_node.keys[0]).__name__}")
print(f"Dict 键值: {dict_node.keys[0].value}")