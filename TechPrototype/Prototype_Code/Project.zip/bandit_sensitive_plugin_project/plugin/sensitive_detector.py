import ast
import re
import bandit
from bandit.core import test_properties as test

SENSITIVE_PATTERNS = {
    'password', 'pwd', 'passwd', 'secret', 'token', 'api_key', 'apikey',
    'private_key', 'privatekey', 'access_key', 'accesskey', 'db_password',
    'database_password', 'aws_secret', 'aws_key', 'jwt_secret', 'auth_token'
}

MIN_SECRET_LENGTH = 5


def _is_sensitive_name(name: str) -> bool:
    if not name:
        return False
    name_lower = name.lower()
    return any(pattern in name_lower for pattern in SENSITIVE_PATTERNS)


def _looks_like_a_secret(value: str) -> bool:
    if not isinstance(value, str) or len(value) < MIN_SECRET_LENGTH:
        return False
    has_upper = any(c.isupper() for c in value)
    has_lower = any(c.islower() for c in value)
    has_digit = any(c.isdigit() for c in value)
    has_special = bool(re.search(r'[_\-=!@#$%^&*]', value))
    return (has_upper and has_lower) or has_digit or has_special


# B901: 赋值语句中的硬编码
@test.checks('Assign')
@test.test_id('B901')
def detect_hardcoded_secrets_in_assignment(context):
    node = context.node

    # 获取变量名
    var_name = None

    # 处理赋值目标
    if hasattr(node, 'targets'):
        # 多个赋值目标 a = b = "value"（罕见，只取第一个）
        target = node.targets[0]
    elif hasattr(node, 'target'):
        target = node.target
    else:
        return None

    # 提取变量名
    if isinstance(target, ast.Name):
        var_name = target.id
    elif isinstance(target, ast.Attribute):
        var_name = target.attr
    elif isinstance(target, ast.Subscript):
        # dict['key'] = "value" 这种情况跳过
        return None

    # 检测
    if _is_sensitive_name(var_name):
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            secret_val = node.value.value
            if _looks_like_a_secret(secret_val):
                return bandit.Issue(
                    severity=bandit.HIGH,
                    confidence=bandit.MEDIUM,
                    text=f"[B901] 发现硬编码敏感信息: 变量 '{var_name}' = '{secret_val[:20]}...'"
                )


# B902: 字典中的硬编码
@test.checks('Dict')
@test.test_id('B902')
def detect_hardcoded_secrets_in_dict(context):
    node = context.node

    # 确保 keys 和 values 存在
    if not hasattr(node, 'keys') or not hasattr(node, 'values'):
        return None

    for key_node, value_node in zip(node.keys, node.values):
        # 处理字典键
        if isinstance(key_node, ast.Constant) and isinstance(key_node.value, str):
            dict_key = key_node.value

            if _is_sensitive_name(dict_key):
                # 处理字典值
                if isinstance(value_node, ast.Constant) and isinstance(value_node.value, str):
                    secret_val = value_node.value
                    if _looks_like_a_secret(secret_val):
                        return bandit.Issue(
                            severity=bandit.HIGH,
                            confidence=bandit.MEDIUM,
                            text=f"[B902] 发现字典中的硬编码敏感信息: 键 '{dict_key}' = '{secret_val[:20]}...'"
                        )